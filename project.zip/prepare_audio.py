"""Prepara o audio do video: remove o trecho repetido (src/cut.json) e analisa a energia da voz (src/env.json)."""
import json, os, shutil, subprocess, sys
import numpy as np

try:
    import imageio_ffmpeg
    FF = imageio_ffmpeg.get_ffmpeg_exe()
except Exception:
    FF = shutil.which("ffmpeg")
if not FF:
    sys.exit("ffmpeg nao encontrado")

os.makedirs("public", exist_ok=True)
cut = json.load(open("src/cut.json"))
a, b = float(cut["start"]), float(cut["end"])
if b > a:
    filt = (f"[0:a]atrim=0:{a},asetpts=PTS-STARTPTS,afade=t=out:st={max(0,a-0.04)}:d=0.04[x];"
            f"[0:a]atrim=start={b},asetpts=PTS-STARTPTS,afade=t=in:st=0:d=0.04[y];"
            f"[x][y]concat=n=2:v=0:a=1[out]")
    subprocess.run([FF, "-y", "-i", "audio.mp3", "-filter_complex", filt, "-map", "[out]",
                    "-c:a", "libmp3lame", "-b:a", "192k", "public/audio.mp3"], check=True, capture_output=True)
else:
    shutil.copy("audio.mp3", "public/audio.mp3")

# decode to 16 kHz mono and measure energy per video frame (60 fps)
SR, FPS = 16000, 60
raw = subprocess.run([FF, "-i", "public/audio.mp3", "-f", "s16le", "-ac", "1", "-ar", str(SR), "-"],
                     check=True, capture_output=True).stdout
x = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
n_frames = int(len(x) / SR * FPS) + 1
win = 1024
hann = np.hanning(win).astype(np.float32)
freqs = np.fft.rfftfreq(win, 1 / SR)
bands = {"low": (80, 400), "mid": (400, 2000), "high": (2000, 6000)}
masks = {k: (freqs >= lo) & (freqs < hi) for k, (lo, hi) in bands.items()}
out = {k: np.zeros(n_frames, dtype=np.float32) for k in bands}
for f in range(n_frames):
    c = int(f / FPS * SR)
    seg = x[max(0, c - win // 2): c + win // 2]
    if len(seg) < win:
        seg = np.pad(seg, (0, win - len(seg)))
    spec = np.abs(np.fft.rfft(seg * hann))
    for k, m in masks.items():
        out[k][f] = np.sqrt(np.mean(spec[m] ** 2)) if m.any() else 0.0

res = {"fps": FPS}
for k, v in out.items():
    v = np.log1p(v * 30)                      # soft compression
    hi = np.percentile(v, 97) + 1e-6
    v = np.clip(v / hi, 0, 1)
    s = np.zeros_like(v); cur = 0.0
    for i, val in enumerate(v):               # fast attack, slow release
        cur += (val - cur) * (0.45 if val > cur else 0.10)
        s[i] = cur
    res[k] = [round(float(t), 3) for t in s]
json.dump(res, open("src/env.json", "w"))
print("audio ok:", round(len(x) / SR, 2), "s,", n_frames, "frames")
