// from = first sentence of the scene. aur = aurora strength (1 = hero, ~0.5 = discreet background). warm = warm tint of the aurora.
// fx = sound effects: [when, kind, volume?]  when = seconds | "w:word" | "w:word+0.3" | "s:2"
export type FX = [string | number, string, number?];
export type SceneDef = { from: number; v: string; cap?: "low" | "mid" | "off"; aur?: number; warm?: number; fx?: FX[] };

export const SCENES: SceneDef[] = [
  { from: 0, v: "Hero", aur: 1.0, cap: "mid", fx: [[0.05, "rise", 0.2]] },
  { from: 1, v: "Assumption", aur: 0, fx: [["s:0+0.9", "pop", 0.22], ["s:0+1.8", "pop", 0.22], ["s:1+0.4", "pop", 0.22], ["s:2+0.4", "pop", 0.22], ["s:3+0.4", "pop", 0.22]] },
  { from: 5, v: "Distance", aur: 0, fx: [["w:automatically", "tick"], ["w:distance", "thud", 0.3]] },
  { from: 8, v: "Reverse", aur: 0, fx: [["w:small+0.2", "pop"]] },
  { from: 9, v: "Title", aur: 1.0, cap: "off", fx: [["w:franklin", "thud", 0.4]] },
  { from: 10, v: "Assembly", aur: 0, fx: [["w:wealthy", "tick"], ["w:educated", "tick"], ["w:influential", "tick"], ["w:cold", "thud", 0.3]] },
  { from: 14, v: "Usual", aur: 0, fx: [["w:help", "tick"], ["w:useful", "tick"], ["w:value", "tick"], ["w:instead", "whoosh", 0.2]] },
  { from: 17, v: "Book", aur: 0, fx: [["s:0+0.3", "pop"]] },
  { from: 18, v: "NoteExchange", aur: 0, fx: [["w:sent", "whoosh", 0.25], ["w:agreed", "pop"]] },
  { from: 20, v: "ReturnThanks", aur: 0, fx: [["w:thanks", "chime", 0.18]] },
  { from: 21, v: "Friendship", aur: 0, fx: [["w:friendliness", "pop"], ["w:softened", "chime", 0.18]] },
  { from: 25, v: "Quote", aur: 0, warm: 0.3 },
  { from: 27, v: "Hero", aur: 1.0, cap: "mid" },
  { from: 29, v: "Timeline2", aur: 0, fx: [["w:1969", "pop"]] },
  { from: 30, v: "Participants", aur: 0, fx: [["w:money", "drop", 0.4], ["w:divided", "whoosh", 0.25]] },
  { from: 32, v: "ThreeGroups", aur: 0, fx: [["s:0", "pop"], ["s:2", "pop"], ["s:3", "pop"], ["s:5+0.8", "tick"], ["s:6+0.8", "tick"], ["s:7+0.8", "tick"]] },
  { from: 41, v: "WhyDissonance", aur: 0, fx: [["w:dissonance", "pop"]] },
  { from: 43, v: "Dissonance", aur: 0, fx: [["w:tension", "thud", 0.3], ["w:adjusting", "chime", 0.18]] },
  { from: 48, v: "Signal", aur: 0, fx: [["w:capable", "tick"], ["w:trustworthy", "tick"]] },
  { from: 52, v: "SocialVsTrans", aur: 0, fx: [["w:opinion", "tick"], ["w:recommendation", "tick"], ["w:advice", "tick"], ["w:money", "tick"]] },
  { from: 56, v: "Hero", aur: 1.0, cap: "mid" },
  { from: 57, v: "ScalePleaser", aur: 0, fx: [["w:offers", "drop", 0.3], ["w:stays", "drop", 0.3], ["w:covers", "drop", 0.3]] },
  { from: 61, v: "BubblesIntro", aur: 0.5 },
  { from: 62, v: "Bubbles", aur: 0, cap: "off", fx: [["s:0", "pop"], ["s:1", "pop"], ["s:2", "pop"]] },
  { from: 65, v: "ScaleBalance", aur: 0, fx: [["s:0+0.9", "drop", 0.35], ["s:1+0.9", "chime", 0.18]] },
  { from: 67, v: "Calibration2", aur: 0, fx: [["w:works", "pop"], ["w:weakens", "thud", 0.3]] },
  { from: 71, v: "Frictionless", aur: 0, fx: [["w:friction", "whoosh", 0.2]] },
  { from: 74, v: "Mutual", aur: 0, warm: 0.4 },
  { from: 76, v: "DontNeed", aur: 0, fx: [["s:0+0.4", "click", 0.4], ["s:1+0.4", "click", 0.4]] },
  { from: 78, v: "LetHelp", aur: 0, fx: [["w:help+0.2", "chime", 0.2]] },
  { from: 80, v: "Closest", aur: 0, fx: [["w:also", "pop"]] },
  { from: 82, v: "Comments2", aur: 0, fx: [[0.2, "pop"], ["w:comments+0.1", "chime", 0.2]] },
];
