import React from "react";
import { AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame } from "remotion";
import { fontFamily } from "./font";
import { A, clamp, eIO, eOut, FPS, lerp, SM, SN, spr, themeAt, ThemeCtx, useTheme } from "./lib";
import { emphasis } from "./data";
import { CHUNKS, SC, SFX, SFX_LEN, TOTAL, Chunk } from "./timeline";
import * as V1 from "./visuals1";
import * as V2 from "./visuals2";
import * as V3 from "./visuals3";
import * as V4 from "./visuals4";

const VIS: Record<string, React.FC<any>> = { ...V1, ...V2, ...V3, ...V4 } as any;
const THEME_FADE = 0.7;
const TAIL = 0.55;

function themeM(t: number) {
  let i = 0;
  while (i + 1 < SC.length && SC[i + 1].start <= t) i++;
  const cur = SC[i].def.theme;
  const prev = i > 0 ? SC[i - 1].def.theme : cur;
  return lerp(prev, cur, eIO(clamp((t - SC[i].start) / THEME_FADE)));
}

const Caption: React.FC<{ c: Chunk; t: number }> = ({ c, t }) => {
  const th = useTheme();
  const ex = eIO(clamp((t - c.ex0) / (c.ex1 - c.ex0)));
  const mid = c.pos === "mid";
  const size = mid ? 92 : 64;
  const y = mid ? 540 : 878;
  return (
    <div
      style={{
        position: "absolute", left: 960 - 780, width: 1560, top: y - 120, height: 240,
        display: "flex", flexWrap: "wrap", justifyContent: "center", alignContent: "center", alignItems: "center",
        fontSize: size, lineHeight: 1.16, fontWeight: 600, letterSpacing: "-0.025em", textAlign: "center",
        opacity: 1 - ex, transform: `translateY(${-ex * 24}px)`, filter: ex > 0.01 ? `blur(${ex * 8}px)` : undefined,
      }}
    >
      {c.words.map((w, i) => {
        const p = spr(t - (w.start - 0.07), SN);
        const q = clamp(p);
        const e = emphasis(w.text);
        const color = e === 1 ? th.blue : e === 2 ? th.warm : th.fg;
        return (
          <span
            key={i}
            style={{
              display: "inline-block", margin: "0 0.15em", color, fontWeight: e ? 700 : 600,
              opacity: clamp(p * 1.8), transform: `translateY(${(1 - p) * 34}px) scale(${0.94 + 0.06 * p})`,
              filter: q < 0.995 ? `blur(${(1 - q) * 14}px)` : undefined,
            }}
          >
            {w.text}
          </span>
        );
      })}
    </div>
  );
};

export const MyVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const th = themeAt(themeM(t));
  const fade = eIO(clamp((t - (TOTAL - 1.0)) / 0.9));

  return (
    <AbsoluteFill style={{ background: th.bg, fontFamily, overflow: "hidden" }}>
      <Audio src={staticFile("audio.mp3")} />
      {SFX.map((s, i) => (
        <Sequence key={i} from={Math.max(0, Math.round(s.at * FPS))} durationInFrames={Math.ceil((SFX_LEN[s.kind] ?? 1) * FPS) + 2} layout="none">
          <Audio src={staticFile(`sfx/${s.kind}.wav`)} volume={s.vol} />
        </Sequence>
      ))}
      <div style={{ position: "absolute", left: 0, top: 0, width: 1920, height: 1080, transform: "scale(1.3333333)", transformOrigin: "0 0" }}>
        <ThemeCtx.Provider value={th}>
          {SC.map((sc) => {
            if (t < sc.start - 0.05 || t > sc.end + TAIL) return null;
            const lt = t - sc.start;
            const dur = sc.end - sc.start;
            const enter = spr(lt, SM);
            const ex = eIO(clamp((lt - dur) / TAIL));
            const Vis = VIS[sc.def.v];
            if (!Vis) return null;
            return (
              <div key={sc.i} style={{ position: "absolute", inset: 0, opacity: clamp(enter * 1.5) * (1 - ex), transform: `scale(${0.97 + 0.03 * enter - 0.025 * ex})`, transformOrigin: "960px 420px" }}>
                <Vis lt={lt} dur={dur} S={sc.S} SE={sc.SE} W={sc.W} />
              </div>
            );
          })}
          {CHUNKS.map((c, i) => (t >= c.start - 0.12 && t <= c.ex1 ? <Caption key={i} c={c} t={t} /> : null))}
        </ThemeCtx.Provider>
        <div style={{ position: "absolute", inset: 0, background: "#000", opacity: fade }} />
      </div>
    </AbsoluteFill>
  );
};
