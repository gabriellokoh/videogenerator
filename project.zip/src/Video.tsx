import React from "react";
import { AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame } from "remotion";
import { fontFamily } from "./font";
import { clamp, eIO, FPS, lerp, SM, SN, spr, themeAt, ThemeCtx, useTheme } from "./lib";
import { emphasis, WORDS } from "./data";
import { CHUNKS, SC, SFX, SFX_LEN, TOTAL, Chunk } from "./timeline";
import env from "./env.json";
import { VIS } from "./visuals";

const TAIL = 0.55;

// ---------- voice energy: audio analysis (env.json) when available, otherwise word timing ----------
const NF = Math.ceil(TOTAL * FPS) + 2;
const VOICE: number[] = (() => {
  const a = new Array(NF).fill(0);
  for (const w of WORDS) {
    const f0 = Math.max(0, Math.floor(w.start * FPS)), f1 = Math.min(NF - 1, Math.ceil(w.end * FPS));
    for (let f = f0; f <= f1; f++) a[f] = 1;
  }
  let v = 0;
  for (let f = 0; f < NF; f++) { const k = a[f] > v ? 0.35 : 0.06; v += (a[f] - v) * k; a[f] = v; }
  return a;
})();
const HAS_ENV = Array.isArray((env as any).low) && (env as any).low.length > 10;
function energy(frame: number, t: number) {
  if (HAS_ENV) {
    const e: any = env;
    const i = Math.min(frame, e.low.length - 1);
    return { low: e.low[i], mid: e.mid[i], high: e.high[i] };
  }
  const a = VOICE[Math.min(frame, NF - 1)] * 0.8;
  return { low: a * (0.65 + 0.35 * Math.sin(t * 2.1)), mid: a * (0.65 + 0.35 * Math.sin(t * 3.3 + 1)), high: a * (0.55 + 0.45 * Math.sin(t * 4.7 + 2)) };
}

function sceneIdx(t: number) {
  let i = 0;
  while (i + 1 < SC.length && SC[i + 1].start <= t) i++;
  return i;
}
function auroraParams(t: number) {
  const i = sceneIdx(t);
  const cur = SC[i].def, prev = i > 0 ? SC[i - 1].def : cur;
  const k = eIO(clamp((t - SC[i].start) / 0.9));
  return { level: lerp(prev.aur ?? 0.5, cur.aur ?? 0.5, k), warm: lerp(prev.warm ?? 0, cur.warm ?? 0, k) };
}

const rg = (x: number, y: number, w: number, h: number, rgb: string, a: number) =>
  `radial-gradient(ellipse ${w.toFixed(0)}px ${h.toFixed(0)}px at ${x.toFixed(0)}px ${y.toFixed(0)}px, rgba(${rgb},${a.toFixed(3)}) 0%, rgba(${rgb},${(a * 0.5).toFixed(3)}) 42%, rgba(${rgb},0) 74%)`;

const NOISE = `url("data:image/svg+xml;utf8,${encodeURIComponent(
  "<svg xmlns='http://www.w3.org/2000/svg' width='240' height='240'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='2' stitchTiles='stitch'/><feColorMatrix type='saturate' values='0'/></filter><rect width='100%' height='100%' filter='url(#n)'/></svg>"
)}")`;

const Aurora: React.FC<{ t: number; frame: number }> = ({ t, frame }) => {
  const { level } = auroraParams(t);
  if (level < 0.01) return null;
  const e = energy(frame, t);
  const am = level;
  const sm = 0.9 + 0.2 * level;
  const cx = 960, cy = 440;
  const L = [
    rg(cx - 190 + 50 * Math.sin(t * 0.8), cy - 10 + 22 * Math.cos(t * 0.7), 560 * sm * (1 + 0.25 * e.low), 400 * sm * (1 + 0.25 * e.low), "10,132,255", am * (0.50 + 0.16 * e.low)),
    rg(cx + 200 + 50 * Math.cos(t * 0.6), cy - 50 + 26 * Math.sin(t * 0.9), 540 * sm * (1 + 0.25 * e.mid), 380 * sm * (1 + 0.25 * e.mid), "150,100,255", am * (0.44 + 0.16 * e.mid)),
    rg(cx + 20 + 40 * Math.sin(t * 0.5 + 1), cy + 95 + 20 * Math.cos(t * 0.6), 520 * sm * (1 + 0.25 * e.high), 320 * sm * (1 + 0.25 * e.high), "100,210,255", am * (0.40 + 0.2 * e.high)),
    rg(cx - 60 + 30 * Math.sin(t * 0.9), cy + 30 + 16 * Math.cos(t * 0.5), 300 * sm * (1 + 0.2 * e.mid), 240 * sm * (1 + 0.2 * e.mid), "255,110,190", am * (0.26 + 0.24 * e.mid)),
  ];
  return (
    <>
      <div style={{ position: "absolute", inset: 0, background: L.join(",") }} />
      <div style={{ position: "absolute", inset: 0, backgroundImage: NOISE, opacity: 0.05 * level }} />
    </>
  );
};

const Caption: React.FC<{ c: Chunk; t: number }> = ({ c, t }) => {
  const th = useTheme();
  const ex = eIO(clamp((t - c.ex0) / (c.ex1 - c.ex0)));
  const mid = c.pos === "mid";
  const size = mid ? 96 : 64;
  const y = mid ? 560 : 878;
  return (
    <div
      style={{
        position: "absolute", left: 960 - 780, width: 1560, top: y - 120, height: 240,
        display: "flex", flexWrap: "wrap", justifyContent: "center", alignContent: "center", alignItems: "center",
        fontSize: size, lineHeight: 1.16, fontWeight: 600, letterSpacing: "-0.025em", textAlign: "center",
        opacity: 1 - ex, transform: `translateY(${-ex * 24}px)`, filter: ex > 0.01 ? `blur(${ex * 8}px)` : undefined,
      }}
    >
      {c.words.map((w, i) => {
        const p = spr(t - (w.start - 0.07), SN);
        const q = clamp(p);
        const e = emphasis(w.text);
        const color = e === 1 ? th.blue : e === 2 ? th.warm : th.fg;
        return (
          <span key={i} style={{ display: "inline-block", margin: "0 0.15em", color, fontWeight: e ? 700 : 600, opacity: clamp(p * 1.8), transform: `translateY(${(1 - p) * 34}px) scale(${0.94 + 0.06 * p})`, filter: q < 0.995 ? `blur(${(1 - q) * 14}px)` : undefined }}>
            {w.text}
          </span>
        );
      })}
    </div>
  );
};

export const MyVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const th = themeAt(1);
  const fade = eIO(clamp((t - (TOTAL - 1.0)) / 0.9));

  return (
    <AbsoluteFill style={{ background: th.bg, fontFamily, overflow: "hidden" }}>
      <Audio src={staticFile("audio.mp3")} />
      {SFX.map((s, i) => (
        <Sequence key={i} from={Math.max(0, Math.round(s.at * FPS))} durationInFrames={Math.ceil((SFX_LEN[s.kind] ?? 1) * FPS) + 2} layout="none">
          <Audio src={staticFile(`sfx/${s.kind}.wav`)} volume={s.vol} />
        </Sequence>
      ))}
      <div style={{ position: "absolute", left: 0, top: 0, width: 1920, height: 1080, transform: "scale(1.3333333)", transformOrigin: "0 0" }}>
        <ThemeCtx.Provider value={th}>
          <Aurora t={t} frame={frame} />
          {SC.map((sc) => {
            if (t < sc.start - 0.05 || t > sc.end + TAIL) return null;
            const lt = t - sc.start;
            const dur = sc.end - sc.start;
            const enter = spr(lt, SM);
            const ex = eIO(clamp((lt - dur) / TAIL));
            const Vis = VIS[sc.def.v];
            if (!Vis) return null;
            const op = clamp(enter * 1.5) * (1 - ex);
            return (
              <div key={sc.i} style={{ position: "absolute", inset: 0, opacity: op >= 0.999 ? undefined : op, transform: `scale(${0.97 + 0.03 * enter - 0.025 * ex})`, transformOrigin: "960px 440px" }}>
                <Vis lt={lt} dur={dur} S={sc.S} SE={sc.SE} W={sc.W} />
              </div>
            );
          })}
          {CHUNKS.map((c, i) => (t >= c.start - 0.12 && t <= c.ex1 ? <Caption key={i} c={c} t={t} /> : null))}
        </ThemeCtx.Provider>
        <div style={{ position: "absolute", inset: 0, background: th.bg, opacity: fade }} />
      </div>
    </AbsoluteFill>
  );
};
