import React from "react";

export const W = 1920;
export const H = 1080;
export const FPS = 60;

export const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

// ---------- easing (cubic-bezier, same idea as CSS / Apple curves) ----------
export function bez(x1: number, y1: number, x2: number, y2: number) {
  const cx = 3 * x1, bx = 3 * (x2 - x1) - cx, ax = 1 - cx - bx;
  const cy = 3 * y1, by = 3 * (y2 - y1) - cy, ay = 1 - cy - by;
  const sx = (t: number) => ((ax * t + bx) * t + cx) * t;
  const sy = (t: number) => ((ay * t + by) * t + cy) * t;
  const dx = (t: number) => (3 * ax * t + 2 * bx) * t + cx;
  return (x: number) => {
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    let t = x;
    for (let i = 0; i < 8; i++) {
      const e = sx(t) - x;
      if (Math.abs(e) < 1e-6) return sy(t);
      const d = dx(t);
      if (Math.abs(d) < 1e-6) break;
      t -= e / d;
    }
    let lo = 0, hi = 1;
    t = x;
    for (let i = 0; i < 30; i++) {
      const e = sx(t);
      if (Math.abs(e - x) < 1e-6) break;
      if (x > e) lo = t; else hi = t;
      t = (hi - lo) / 2 + lo;
    }
    return sy(t);
  };
}
export const eOut = bez(0.16, 1, 0.3, 1);
export const eIO = bez(0.65, 0, 0.35, 1);
export const eStd = bez(0.25, 0.1, 0.25, 1);

/** ramp: 0..1 between times a and b with easing */
export const rp = (x: number, a: number, b: number, e: (p: number) => number = eOut) =>
  e(clamp((x - a) / (b - a)));

// ---------- springs (closed form, Apple-style response / damping) ----------
export type Sp = { r: number; z: number };
export const SM: Sp = { r: 0.6, z: 1 };      // smooth, no bounce
export const SN: Sp = { r: 0.46, z: 0.86 };  // snappy, tiny overshoot
export const BN: Sp = { r: 0.62, z: 0.66 };  // bouncy
export const SOFT: Sp = { r: 1.0, z: 1 };    // slow and gentle

export function spr(t: number, s: Sp = SM) {
  if (t <= 0) return 0;
  const w0 = (2 * Math.PI) / s.r;
  const z = s.z;
  if (z < 1) {
    const wd = w0 * Math.sqrt(1 - z * z);
    return 1 - Math.exp(-z * w0 * t) * (Math.cos(wd * t) + ((z * w0) / wd) * Math.sin(wd * t));
  }
  if (z === 1) return 1 - Math.exp(-w0 * t) * (1 + w0 * t);
  const q = Math.sqrt(z * z - 1);
  const s1 = -w0 * (z - q), s2 = -w0 * (z + q);
  return 1 - (s2 * Math.exp(s1 * t) - s1 * Math.exp(s2 * t)) / (s2 - s1);
}
/** spring starting at time t0 */
export const A = (lt: number, t0: number, p: Sp = SM) => spr(lt - t0, p);

export function rnd(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---------- theme (dark <-> light, blended smoothly) ----------
const hex = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const mixRGB = (a: string, b: string, m: number) => {
  const A_ = hex(a), B_ = hex(b);
  return A_.map((v, i) => v + (B_[i] - v) * m);
};
const css = (c: number[], a = 1) => `rgba(${Math.round(c[0])},${Math.round(c[1])},${Math.round(c[2])},${a})`;

export type Theme = {
  m: number; bg: string; fg: string; fgA: (a: number) => string; surface: string;
  blue: string; warm: string; green: string; red: string; gray: string; shadow: string;
};
export function themeAt(m: number): Theme {
  const fg = mixRGB("#F5F5F7", "#1D1D1F", m);
  return {
    m,
    bg: css(mixRGB("#000000", "#F5F5F7", m)),
    fg: css(fg),
    fgA: (a: number) => css(fg, a),
    surface: css(mixRGB("#1C1C1E", "#FFFFFF", m)),
    blue: css(mixRGB("#0A84FF", "#0071E3", m)),
    warm: css(mixRGB("#FF9F0A", "#FF9500", m)),
    green: css(mixRGB("#30D158", "#34C759", m)),
    red: css(mixRGB("#FF453A", "#FF3B30", m)),
    gray: css(mixRGB("#2C2C2E", "#D1D1D6", m)),
    shadow: `0 0 0 2px ${css(fg, 0.14)}, 0 20px 50px rgba(0,0,0,${(0.14 * m).toFixed(3)})`,
  };
}
export const ThemeCtx = React.createContext<Theme>(themeAt(0));
export const useTheme = () => React.useContext(ThemeCtx);

// ---------- primitives (everything centered on x,y) ----------
export const Box = ({ x, y, w, h, r = 0, style, children }: any) => (
  <div
    style={{
      position: "absolute", left: x - w / 2, top: y - h / 2, width: w, height: h,
      borderRadius: r, boxSizing: "border-box", ...style,
    }}
  >
    {children}
  </div>
);
export const Circ = ({ x, y, d, style, children }: any) => (
  <Box x={x} y={y} w={d} h={d} r={d / 2} style={style}>{children}</Box>
);
export const Label = ({ x, y, size = 36, weight = 600, color, children, style, w = 1400 }: any) => (
  <div
    style={{
      position: "absolute", left: x - w / 2, top: y - size, width: w, height: size * 2,
      display: "flex", alignItems: "center", justifyContent: "center", fontSize: size,
      fontWeight: weight, color, letterSpacing: "-0.01em", whiteSpace: "nowrap", ...style,
    }}
  >
    {children}
  </div>
);
export const Check = ({ s = 28, c = "#fff" }: any) => (
  <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth={3.2} strokeLinecap="round" strokeLinejoin="round">
    <path d="M5 12.5l4.5 4.5L19 7.5" />
  </svg>
);
export const Cross = ({ s = 28, c = "#fff" }: any) => (
  <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth={3.2} strokeLinecap="round" strokeLinejoin="round">
    <path d="M6 6l12 12M18 6L6 18" />
  </svg>
);
