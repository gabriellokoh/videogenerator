import React from "react";
import { A, BN, Box, Check, Circ, clamp, Cross, eIO, eOut, Label, lerp, rp, SM, SN, SOFT, spr, useTheme } from "./lib";
import { tw } from "./data";
import { VP, CX, CY, Person } from "./visuals1";

const S_ = (S: number[], k: number, fb: number) => (S[k] !== undefined ? S[k] : fb);
const Arrow = ({ up, c, s = 26 }: any) => (
  <svg width={s} height={s} viewBox="0 0 24 24" fill={c}>
    <path d={up ? "M12 4l8 12H4z" : "M12 20L4 8h16z"} />
  </svg>
);
const Chip = ({ x, y, w, h = 56, p, color, text, icon, tc = "#fff", size = 28 }: any) => (
  <Box x={x} y={y + (1 - p) * 16} w={w} h={h} r={h / 2} style={{ background: color, opacity: clamp(p * 1.6), display: "flex", alignItems: "center", justifyContent: "center", gap: 10, color: tc, fontSize: size, fontWeight: 600, whiteSpace: "nowrap" }}>
    {icon}
    {text}
  </Box>
);

// 5 ------------------------------------------------------------- Candidates
export const Candidates = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const cy = CY + 10;
  const xs = [620, 1300];
  const tD = tw(W, "spilled", 0, S_(S, 3, 12) + 2);
  const fall = 0.42;
  const u = clamp((lt - tD) / fall);
  const land = lt - (tD + fall);
  const hl = [A(lt, S_(S, 1, 4)) * (1 - A(lt, S_(S, 3, 12))), A(lt, S_(S, 3, 12))];
  return (
    <>
      {xs.map((x, i) => {
        const p = A(lt, S_(S, 0, 0) + 0.05 + i * 0.18, SN);
        const rec = rp(lt, 0.5, 1.2);
        return (
          <React.Fragment key={i}>
            <Box x={x} y={cy + (1 - p) * 50} w={520} h={430} r={56} style={{ background: th.surface, boxShadow: `${th.shadow}${hl[i] > 0.01 ? `, 0 0 0 ${5 * hl[i]}px ${th.blue}` : ""}`, opacity: clamp(p * 1.6) }}>
              <div style={{ position: "absolute", left: 36, top: 28, fontSize: 28, fontWeight: 600, color: th.fgA(0.45) }}>{i === 0 ? "Candidate A" : "Candidate B"}</div>
            </Box>
            <div style={{ opacity: clamp(p * 1.6), transform: `translateY(${(1 - p) * 50}px)` }}>
              <Person x={x} y={cy - 40} s={150} color={th.gray} />
              {Array.from({ length: 15 }).map((_, k) => {
                const hgt = 10 + 34 * Math.abs(Math.sin(lt * 5.2 + k * 0.75)) * (0.5 + 0.5 * Math.sin(k * 0.5 + 1)) * rec;
                return <Box key={k} x={x - 126 + k * 18} y={cy + 86} w={9} h={hgt} r={4.5} style={{ background: th.fgA(0.28) }} />;
              })}
              <Box x={x} y={cy + 150} w={380} h={14} r={7} style={{ background: th.fgA(0.1) }} />
              <Box x={x - 190 + 380 * 0.46} y={cy + 150} w={380 * 0.92 * rp(lt, 0.8, 1.6)} h={14} r={7} style={{ background: th.blue, transform: `translateX(${-(380 * 0.46) + (380 * 0.92 * rp(lt, 0.8, 1.6)) / 2}px)` }} />
            </div>
          </React.Fragment>
        );
      })}
      <Chip x={xs[0]} y={cy + 262} w={270} p={A(lt, S_(S, 1, 4))} color={th.blue} text="Nearly perfect" />
      <Chip x={xs[0] + 150} y={cy - 165} w={200} h={48} size={24} p={A(lt, S_(S, 2, 8), SN)} color={th.green} icon={<Check s={22} />} text="0 mistakes" />
      <Chip x={xs[1]} y={cy + 262} w={270} p={A(lt, S_(S, 3, 12) + 0.3)} color={th.blue} text="Also competent" />
      {u > 0 && land < 0 && <Circ x={xs[1]} y={-60 + (cy - 10 + 60) * u * u} d={36} style={{ background: th.warm }} />}
      {land > 0 && (
        <>
          <Circ x={xs[1]} y={cy - 10} d={30 + 90 * rp(land, 0, 0.7)} style={{ background: th.warm, opacity: 0.9 * (1 - 0.25 * rp(land, 0, 2)) }} />
          <Circ x={xs[1]} y={cy - 10} d={40 + 330 * rp(land, 0, 0.9)} style={{ border: `4px solid ${th.warm}`, opacity: 1 - rp(land, 0, 0.9, eOut) }} />
        </>
      )}
    </>
  );
};

// 6 -------------------------------------------------------------------- Meter
export const Meter = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const x0 = 560, tw_ = 1000;
  const v1 = lerp(lerp(0.45, 0.84, A(lt, S_(S, 1, 2) + 0.2, SM)), 0.95, A(lt, S_(S, 2, 6) + 0.1, SM));
  const tl = tw(W, "less", 0, S_(S, 3, 10) + 3);
  const v2 = lerp(0.5, 0.2, A(lt, tl - 0.1, SM));
  const r2 = A(lt, S_(S, 3, 10) - 0.1, SN);
  const row = (y: number, label: string, v: number, color: string, p: number, up: boolean) => (
    <>
      <Label x={320} y={y} size={36} weight={600} color={th.fg} w={400} style={{ opacity: clamp(p * 1.6), justifyContent: "flex-end" }}>{label}</Label>
      <Box x={x0 + tw_ / 2} y={y} w={tw_} h={34} r={17} style={{ background: th.fgA(0.12), opacity: clamp(p * 1.6) }} />
      <div style={{ position: "absolute", left: x0, top: y - 17, width: Math.max(34, tw_ * v), height: 34, borderRadius: 17, background: color, opacity: clamp(p * 1.6), boxShadow: `0 0 36px ${color}` }} />
      <Circ x={x0 + Math.max(34, tw_ * v) + 52} y={y} d={50} style={{ background: th.fgA(0.12), display: "flex", alignItems: "center", justifyContent: "center", opacity: clamp(p * 1.6) }}>
        <Arrow up={up} c={up ? th.green : th.red} />
      </Circ>
    </>
  );
  return (
    <>
      <Label x={CX} y={190} size={30} weight={600} color={th.fgA(0.5)} style={{ letterSpacing: "0.2em", opacity: A(lt, 0.1) }}>LIKABILITY</Label>
      {row(340, "Competent", v1, th.blue, A(lt, 0.2, SN), true)}
      {row(520, "Average", v2, th.warm, r2, v2 > 0.34)}
      {lt < S_(S, 1, 2) && <Label x={CX} y={430} size={180} weight={700} color={th.fgA(0.9)} style={{ opacity: A(lt, 0.3, BN) * (1 - A(lt, S_(S, 1, 2) - 0.2)), transform: `scale(${A(lt, 0.3, BN)})` }}>?</Label>}
    </>
  );
};

// 7 ----------------------------------------------------------------- Contrast
export const Contrast = ({ lt, W }: VP) => {
  const th = useTheme();
  const tM = tw(W, "mistake", 0, 1.2);
  const tC = tw(W, "contrast", 0, 2.3);
  const split = A(lt, tC - 0.1, SN);
  const rad = 70 * A(lt, tC - 0.1, SM);
  const dot = A(lt, tM - 0.1, BN) * (1 - rp(lt, tM + 0.7, tM + 1.1));
  const base = A(lt, 0.1, SN);
  return (
    <>
      <Box x={CX - 90 - 24 * split} y={CY} w={180} h={360} r={`70px ${rad}px ${rad}px 70px`} style={{ background: th.fg, transform: `scale(${base})` }} />
      <Box x={CX + 90 + 24 * split} y={CY} w={180} h={360} r={`${rad}px 70px 70px ${rad}px`} style={{ background: th.fg, transform: `scale(${base})`, opacity: 1 - 0.0 }}>
        <div style={{ position: "absolute", inset: 0, borderRadius: "inherit", background: th.surface, border: `5px solid ${th.fgA(0.85)}`, opacity: split, boxSizing: "border-box" }} />
      </Box>
      <Circ x={CX + 70} y={CY - 80} d={48 * dot} style={{ background: th.warm, boxShadow: `0 0 30px ${th.warm}` }} />
    </>
  );
};

// 8 ---------------------------------------------------------------------- Real
export const Real = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const pills: [string, number, number][] = [
    ["Real", tw(W, "real", 0, 1.5), 210],
    ["Approachable", tw(W, "approachable", 0, 3.2), 420],
    ["Safe", tw(W, "safe", 0, 4.4), 220],
  ];
  const gap = 36;
  const total = pills.reduce((a, p) => a + p[2], 0) + gap * 2;
  let cx = CX - total / 2;
  const out = A(lt, S_(S, 1, 7.8) - 0.1, SM);
  const ringP = A(lt, S_(S, 1, 7.8) + 0.1, SN);
  const tr = tw(W, "trust", 0, 12);
  const dim = rp(lt, tr - 0.2, tr + 0.5);
  return (
    <>
      {pills.map(([txt, t, w], i) => {
        const x = cx + w / 2;
        cx += w + gap;
        const p = A(lt, t - 0.1, SN);
        return (
          <Box key={txt} x={x} y={CY + (1 - p) * 40 - out * 40} w={w} h={104} r={52} style={{ background: th.fg, color: th.bg, opacity: clamp(p * 1.6) * (1 - out), display: "flex", alignItems: "center", justifyContent: "center", gap: 14, fontSize: 44, fontWeight: 600 }}>
            
            
            {txt}
          </Box>
        );
      })}
      <Circ x={CX} y={CY} d={330 * ringP} style={{ border: `12px solid ${th.fg}`, opacity: (1 - 0.8 * dim) * clamp(ringP * 1.6), transform: `scale(${1 - 0.05 * dim})` }} />
      <Circ x={CX} y={CY} d={250 * ringP} style={{ border: `2px solid ${th.fgA(0.3)}`, opacity: (1 - dim) * clamp(ringP) }} />
    </>
  );
};

// 9 ---------------------------------------------------------------------- Lens
export const Lens = ({ lt, dur }: VP) => {
  const th = useTheme();
  const cols = 13, rows = 5, gap = 120;
  const k = rp(lt, 0.15, dur - 0.1, eIO);
  const lx = lerp(CX - 760, CX + 760, k);
  const ly = CY + 36 * Math.sin(lt * 2.6);
  const R = 150;
  return (
    <>
      {Array.from({ length: cols * rows }).map((_, n) => {
        const c = n % cols, r = Math.floor(n / cols);
        const x = CX + (c - (cols - 1) / 2) * gap, y = CY + (r - (rows - 1) / 2) * gap;
        const d = Math.hypot(x - lx, y - ly);
        const f = clamp(1 - d / (R * 0.95));
        const ff = f * f * (3 - 2 * f);
        const p = A(lt, 0.05 + (c + r) * 0.015, SN);
        return (
          <React.Fragment key={n}>
            <Circ x={x} y={y} d={(22 + 20 * ff) * p} style={{ background: th.fgA(0.22) }} />
            <Circ x={x} y={y} d={(22 + 20 * ff) * p} style={{ background: th.blue, opacity: ff }} />
          </React.Fragment>
        );
      })}
      <Circ x={lx} y={ly} d={R * 2} style={{ border: `9px solid ${th.fg}` }} />
      <Box x={lx + R * 0.707 + 75 * 0.707} y={ly + R * 0.707 + 75 * 0.707} w={170} h={22} r={11} style={{ background: th.fg, transform: "rotate(45deg)" }} />
    </>
  );
};

// 10 --------------------------------------------------------------------- Room
export const Room = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const tR = tw(W, "respected", 0, 3);
  const tA = tw(W, "awkward", 0, S_(S, 1, 6) + 2);
  const tS = tw(W, "smile", 0, tA + 1.2);
  const tK = tw(W, "keep", 0, tS + 1.5);
  const hi = A(lt, tR - 0.15, SN);
  const lean = A(lt, tK - 0.1, SOFT);
  const bub = A(lt, tA - 0.15, BN);
  const smile = A(lt, tS - 0.1, SN);
  return (
    <>
      {Array.from({ length: 27 }).map((_, n) => {
        const c = n % 9, r = Math.floor(n / 9);
        if (c === 4 && r === 1) return null;
        const bx = CX + (c - 4) * 150, by = CY + (r - 1) * 130;
        const x = lerp(bx, CX + (bx - CX) * 0.84, lean), y = lerp(by, CY + (by - CY) * 0.84, lean);
        return <Circ key={n} x={x} y={y} d={64 * A(lt, 0.05 + (c + r) * 0.04, SN)} style={{ background: th.fgA(0.16 + 0.2 * lean) }} />;
      })}
      {[0, 1].map((i) => {
        const q = (lt * 0.5 + i / 2) % 1;
        return <Circ key={i} x={CX} y={CY} d={100 + q * 380} style={{ border: `2px solid ${th.blue}`, opacity: (1 - q) * 0.5 * hi }} />;
      })}
      <Circ x={CX} y={CY} d={64 + 44 * hi} style={{ background: th.fgA(0.16 + 0.84 * hi), boxShadow: hi > 0.05 ? `0 0 ${50 * hi}px ${th.blue}` : "none" }}>
        <div style={{ position: "absolute", inset: 0, borderRadius: "50%", background: th.blue, opacity: hi }} />
      </Circ>
      <svg style={{ position: "absolute", left: CX - 60, top: CY + 52, overflow: "visible" }} width={120} height={50}>
        <path d="M10 8 Q60 52 110 8" fill="none" stroke={th.fg} strokeWidth={8} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - smile} />
      </svg>
      <Box x={CX + 200} y={CY - 140 - 20 * (1 - bub)} w={250} h={96} r={48} style={{ background: th.fg, color: th.bg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 46, fontWeight: 600, opacity: clamp(bub * 1.6), transform: `scale(${bub}) rotate(${Math.sin(lt * 9) * 3 * (1 - rp(lt, tA + 0.6, tA + 1.2))}deg)` }}>
        um…
      </Box>
      <Circ x={CX + 98} y={CY - 76} d={22 * bub} style={{ background: th.fg }} />
      <Circ x={CX + 70} y={CY - 46} d={13 * bub} style={{ background: th.fg }} />
    </>
  );
};

// 11 ----------------------------------------------------------------- Polished
export const Polished = ({ lt, dur }: VP) => {
  const th = useTheme();
  const p = A(lt, 0.1, SOFT);
  const fy = 14 * Math.sin(lt * 1.8);
  const sweep = ((lt * 0.5) % 1.6) - 0.3;
  return (
    <>
      <Box x={CX} y={CY + 196} w={260 * (1 - 0.05 * Math.sin(lt * 1.8))} h={34} r={17} style={{ background: "rgba(0,0,0,0.16)", filter: "blur(14px)", opacity: p }} />
      <Circ x={CX} y={CY + fy - 10} d={320 * p} style={{ background: "radial-gradient(circle at 32% 26%, #ffffff 0%, #eceef6 26%, #b8bfd2 62%, #8a90a6 100%)", overflow: "hidden", boxShadow: "inset -18px -24px 50px rgba(60,70,100,0.35), 0 30px 60px rgba(0,0,0,0.12)" }}>
        <div style={{ position: "absolute", top: -40, bottom: -40, left: `${sweep * 100}%`, width: 60, background: "rgba(255,255,255,0.55)", transform: "rotate(22deg)", filter: "blur(10px)", borderRadius: 30 }} />
      </Circ>
    </>
  );
};

// 12 -------------------------------------------------------------- PerfectList
export const PerfectList = ({ lt, S }: VP) => {
  const th = useTheme();
  const rows = ["Perfect posture", "Perfect answers", "Perfect timing", "No hesitation", "No visible flaws"];
  return (
    <>
      {rows.map((txt, i) => {
        const p = A(lt, S_(S, i, i * 1.2) - 0.05, SN);
        const good = i < 3;
        const y = CY + (i - 2) * 112 - 6;
        return (
          <Box key={i} x={CX + (1 - p) * 70} y={y} w={820} h={94} r={47} style={{ background: th.surface, boxShadow: th.shadow, opacity: clamp(p * 1.6), display: "flex", alignItems: "center", paddingLeft: 22, gap: 26, fontSize: 40, fontWeight: 600, color: good ? th.fg : th.fgA(0.5) }}>
            <div style={{ width: 52, height: 52, borderRadius: 26, background: good ? th.blue : th.fgA(0.14), display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${A(lt, S_(S, i, i * 1.2) + 0.1, BN)})` }}>
              {good ? <Check s={28} /> : <div style={{ width: 22, height: 5, borderRadius: 3, background: th.fgA(0.5) }} />}
            </div>
            {txt}
          </Box>
        );
      })}
    </>
  );
};
