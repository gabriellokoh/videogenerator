import React from "react";
import { A, BN, Box, Check, Circ, clamp, Cross, eIO, eOut, eStd, Label, lerp, rnd, rp, SM, SN, SOFT, spr, useTheme } from "./lib";
import { tw, Wd } from "./data";

export type VP = { lt: number; dur: number; S: number[]; SE: number[]; W: Wd[] };
export const CX = 960;
export const CY = 410;

export const Person = ({ x, y, s, color, style }: any) => (
  <>
    <Circ x={x} y={y - s * 0.3} d={s * 0.46} style={{ background: color, ...style }} />
    <Box x={x} y={y + s * 0.26} w={s * 0.92} h={s * 0.5} r={`${s * 0.46}px ${s * 0.46}px ${s * 0.12}px ${s * 0.12}px`} style={{ background: color, ...style }} />
  </>
);
const S_ = (S: number[], k: number, fb: number) => (S[k] !== undefined ? S[k] : fb);

// 0 ------------------------------------------------------------------ Intro
export const Intro = ({ lt }: VP) => {
  const th = useTheme();
  const p = A(lt, 0.1, SOFT);
  const br = 1 + 0.035 * Math.sin(lt * 2.4);
  return (
    <>
      {[0, 1, 2].map((i) => {
        const q = (lt * 0.45 + i / 3) % 1;
        return <Circ key={i} x={CX} y={CY} d={170 + q * 560} style={{ border: `2px solid ${th.fg}`, opacity: (1 - q) * 0.3 * p }} />;
      })}
      <Circ x={CX} y={CY} d={170 * p * br} style={{ background: th.fg, boxShadow: `0 0 140px 20px ${th.fgA(0.28)}` }} />
    </>
  );
};

// 1 -------------------------------------------------------------------- Pull
export const Pull = ({ lt, dur, S }: VP) => {
  const th = useTheme();
  const N = 10;
  const k = rp(lt, 0.4, dur - 0.4, eIO);
  const jump = A(lt, S_(S, 1, dur * 0.5), SOFT);
  const R = 120 + 150 * k + 180 * jump;
  return (
    <>
      <Circ x={CX} y={CY} d={96 * A(lt, 0.1)} style={{ background: th.blue, boxShadow: `0 0 70px 6px ${th.blue}` }} />
      {Array.from({ length: N }).map((_, i) => {
        const a = (i / N) * Math.PI * 2 + lt * 0.2;
        const ap = A(lt, 0.2 + i * 0.05);
        return (
          <Circ key={i} x={CX + Math.cos(a) * R} y={CY + Math.sin(a) * R * 0.6} d={36 * ap}
            style={{ background: th.fg, opacity: 1 - 0.55 * (k * 0.5 + jump * 0.5) }} />
        );
      })}
    </>
  );
};

// 2 ------------------------------------------------------------------ Magnet
export const Magnet = ({ lt, W }: VP) => {
  const th = useTheme();
  const N = 10;
  const tm = tw(W, "strangely", 0, 1.5) - 0.2;
  const pull = rp(lt, tm, tm + 1.9, eOut);
  const R = lerp(430, 120, pull);
  const glow = rp(lt, tm + 0.8, tm + 2.2, eOut);
  return (
    <>
      {[0, 1].map((i) => {
        const q = (lt * 0.6 + i / 2) % 1;
        return <Circ key={i} x={CX} y={CY} d={110 + q * 420} style={{ border: `2px solid ${th.blue}`, opacity: glow * (1 - q) * 0.6 }} />;
      })}
      <Circ x={CX} y={CY} d={(96 + 30 * glow) * A(lt, 0.1)} style={{ background: th.blue, boxShadow: `0 0 ${60 + 80 * glow}px ${6 + 14 * glow}px ${th.blue}` }} />
      {Array.from({ length: N }).map((_, i) => {
        const a = (i / N) * Math.PI * 2 + lt * (0.2 + 0.5 * pull);
        return <Circ key={i} x={CX + Math.cos(a) * R} y={CY + Math.sin(a) * R * 0.6} d={36 * A(lt, 0.1 + i * 0.04)} style={{ background: th.fg, opacity: 0.55 + 0.45 * pull }} />;
      })}
    </>
  );
};

// 3 ------------------------------------------------------------------- Title
export const Title = ({ lt, W }: VP) => {
  const th = useTheme();
  const t0 = tw(W, "this", 0, 0.05);
  const t1 = tw(W, "the", 0, 0.7);
  const t2 = tw(W, "pratfall", 0, 1.0);
  const t3 = tw(W, "effect", 0, 1.3);
  const word = (txt: string, t: number, color: string, wt: number) => {
    const p = A(lt, t - 0.05, SN);
    const q = clamp(p);
    return (
      <span style={{ display: "inline-block", opacity: clamp(p * 1.8), transform: `translateY(${(1 - p) * 50}px) scale(${0.94 + 0.06 * p})`, filter: `blur(${(1 - q) * 16}px)`, color, fontWeight: wt }}>
        {txt}
      </span>
    );
  };
  const kp = A(lt, t0 - 0.05, SM);
  return (
    <>
      <Label x={CX} y={300} size={32} weight={600} color={th.fgA(0.5)} style={{ letterSpacing: "0.22em", opacity: clamp(kp * 1.6), transform: `translateY(${(1 - kp) * 20}px)` }}>
        THIS IS CALLED
      </Label>
      <div style={{ position: "absolute", left: 0, top: 340, width: 1920, height: 220, display: "flex", justifyContent: "center", alignItems: "center", gap: 40, fontSize: 168, letterSpacing: "-0.04em", whiteSpace: "nowrap" }}>
        {word("The", t1, th.fgA(0.45), 500)}
        {word("Pratfall", t2, th.fg, 700)}
        {word("Effect", t3, th.blue, 700)}
      </div>
      <Box x={CX} y={590} w={520 * rp(lt, t3 + 0.1, t3 + 0.9, eOut)} h={12} r={6} style={{ background: th.blue }} />
    </>
  );
};

// 4 --------------------------------------------------------------- Timeline
export const Timeline = ({ lt, dur, W }: VP) => {
  const th = useTheme();
  const years = [1900, 1920, 1940, 1960, 1980, 2000, 2020];
  const x0 = 300, x1 = 1620;
  const xs = years.map((_, i) => x0 + ((x1 - x0) * i) / (years.length - 1));
  const tm = tw(W, "1960s", 0, 1.0) - 0.4;
  const mv = rp(lt, tm, tm + 1.0, eOut);
  const mx = lerp(xs[0], xs[3], mv);
  const yr = Math.round(lerp(1900, 1960, mv));
  return (
    <>
      <Box x={CX} y={500} w={(x1 - x0 + 40) * rp(lt, 0.1, 1.0, eOut)} h={8} r={4} style={{ background: th.fgA(0.2) }} />
      <Box x={(x0 + mx) / 2} y={500} w={Math.max(0, mx - x0)} h={8} r={4} style={{ background: th.blue }} />
      {years.map((y, i) => {
        const p = A(lt, 0.2 + i * 0.07);
        return (
          <React.Fragment key={y}>
            <Circ x={xs[i]} y={500} d={20 * p} style={{ background: i === 3 && mv > 0.9 ? th.blue : th.fgA(0.45) }} />
            <Label x={xs[i]} y={556} size={26} weight={500} color={th.fgA(0.4)} style={{ opacity: p }} w={200}>{y}</Label>
          </React.Fragment>
        );
      })}
      <Circ x={mx} y={500} d={46 * A(lt, tm)} style={{ background: th.blue, boxShadow: `0 0 40px 4px ${th.blue}` }} />
      <Label x={CX} y={310} size={150} weight={700} color={th.fg} style={{ letterSpacing: "-0.04em", opacity: clamp(mv * 2), transform: `translateY(${(1 - mv) * 30}px)` }} w={1000}>
        {mv > 0.98 ? "1960s" : yr}
      </Label>
    </>
  );
};
