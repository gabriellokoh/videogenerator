import raw from "./words.json";

export type Wd = { text: string; start: number; end: number };

/** lowercase, letters and digits only */
export const nk = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, "");

// merge Whisper fragments like "over" + "-apologizing." into "over-apologizing."
export const WORDS: Wd[] = (() => {
  const out: Wd[] = [];
  for (const r of raw as any[]) {
    const tx = String(r.word).trim();
    if (!tx) continue;
    if (tx.startsWith("-") && out.length) {
      const p = out[out.length - 1];
      p.text = p.text + tx;
      p.end = r.end;
    } else out.push({ text: tx, start: r.start, end: r.end });
  }
  return out;
})();

export const SENTS: Wd[][] = (() => {
  const out: Wd[][] = [];
  let cur: Wd[] = [];
  for (const w of WORDS) {
    cur.push(w);
    if (/[.?!]["”’)]*$/.test(w.text)) { out.push(cur); cur = []; }
  }
  if (cur.length) out.push(cur);
  return out;
})();

export const END = WORDS[WORDS.length - 1].end;

/** start time of the nth word whose text starts with key (times in whatever list is given) */
export function tw(words: Wd[], key: string, nth = 0, fb = 0.5): number {
  const k = nk(key);
  let n = 0;
  for (const w of words) {
    if (nk(w.text).startsWith(k)) {
      if (n === nth) return w.start;
      n++;
    }
  }
  return fb;
}

export function chunkSentence(ws: Wd[]): Wd[][] {
  const out: Wd[][] = [];
  let cur: Wd[] = [];
  const chars = (a: Wd[]) => a.map((w) => w.text).join(" ").length;
  for (const w of ws) {
    if (cur.length >= 3 && chars([...cur, w]) > 44) { out.push(cur); cur = []; }
    cur.push(w);
    const soft = /[,;:—]$/.test(w.text);
    if ((soft && cur.length >= 3) || cur.length >= 7) { out.push(cur); cur = []; }
  }
  if (cur.length) {
    if (cur.length <= 2 && out.length && out[out.length - 1].length + cur.length <= 8) {
      out[out.length - 1] = [...out[out.length - 1], ...cur];
    } else out.push(cur);
  }
  return out;
}

const BLUE = new Set(("competent perfect perfection real magnetic pratfall effect contrast status trust confidence " +
  "human approachable safe calibration deliberately memorable trustworthy competence quiet distance flawless " +
  "polished performance").split(" "));
const WARM = new Set(("mistake mistakes flaw flaws error spilled spill coffee awkward imperfect imperfection " +
  "imperfections stumble mess messy").split(" "));
export const emphasis = (text: string): 0 | 1 | 2 => {
  const k = nk(text);
  if (WARM.has(k)) return 2;
  if (BLUE.has(k)) return 1;
  return 0;
};
