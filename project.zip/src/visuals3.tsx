import React from "react";
import { A, BN, Box, Check, Circ, clamp, Cross, eIO, eOut, eStd, Label, lerp, rnd, rp, SM, SN, SOFT, useTheme } from "./lib";
import { tw } from "./data";
import { VP, CX, CY, Person } from "./visuals1";

const S_ = (S: number[], k: number, fb: number) => (S[k] !== undefined ? S[k] : fb);
const Chip = ({ x, y, w, h = 56, p, color, text, icon, tc = "#fff", size = 28 }: any) => (
  <Box x={x} y={y + (1 - p) * 16} w={w} h={h} r={h / 2} style={{ background: color, opacity: clamp(p * 1.6), display: "flex", alignItems: "center", justifyContent: "center", gap: 10, color: tc, fontSize: size, fontWeight: 600, whiteSpace: "nowrap" }}>
    {icon}
    {text}
  </Box>
);

// 13 ------------------------------------------------------------------ Distance
export const Distance = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const g0 = A(lt, 0.1, SN);
  const close = A(lt, S_(S, 0, 0) + 0.2, SN);
  const apart1 = A(lt, S_(S, 1, 3) - 0.05, BN);
  const apart2 = A(lt, S_(S, 2, 6) - 0.05, SOFT);
  const gapPx = lerp(lerp(900, 330, close), 1000, apart1) + 260 * apart2;
  const xa = CX - gapPx / 2, xb = CX + gapPx / 2;
  const td = tw(W, "distance", 0, S_(S, 1, 3) + 1.2);
  const lab = A(lt, td, SN);
  return (
    <>
      <div style={{ position: "absolute", left: xa + 60, top: CY - 2, width: Math.max(0, xb - xa - 120), borderTop: `5px dotted ${th.fgA(0.4)}`, opacity: g0 }} />
      <Circ x={xa} y={CY} d={120 * g0} style={{ background: th.blue, boxShadow: `0 0 50px ${th.blue}` }} />
      <Circ x={xb} y={CY} d={120 * g0} style={{ background: th.fg }} />
      <Label x={xa} y={CY + 110} size={30} color={th.fgA(0.5)} w={200} style={{ opacity: g0 }}>You</Label>
      <Label x={xb} y={CY + 110} size={30} color={th.fgA(0.5)} w={200} style={{ opacity: g0 }}>Them</Label>
      <Label x={CX} y={CY - 60} size={34} weight={600} color={th.warm} style={{ opacity: clamp(lab * 1.6), letterSpacing: "0.2em", transform: `translateY(${(1 - lab) * 14}px)` }}>DISTANCE</Label>
    </>
  );
};

// 14 ----------------------------------------------------------------- TwoThings
export const TwoThings = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const t1 = tw(W, "status", 0, 4.6);
  const t2 = tw(W, "unavailability", 0, 6.1);
  const tT = tw(W, "two", 0, 1.8);
  const cards = [
    { x: 560, t: t1, title: "High status", c: th.blue, icon: "up" },
    { x: 1360, t: t2, title: "Emotionally unavailable", c: th.warm, icon: "bar" },
  ];
  return (
    <>
      {cards.map((c, i) => {
        const ph = A(lt, tT - 0.1 + i * 0.15, SN);
        const p = A(lt, c.t - 0.1, SN);
        return (
          <React.Fragment key={i}>
            <Box x={c.x} y={CY} w={560} h={330} r={60} style={{ border: `4px dashed ${th.fgA(0.25)}`, opacity: clamp(ph * 1.6) * (1 - p), transform: `scale(${0.9 + 0.1 * ph})` }} />
            <Box x={c.x} y={CY + (1 - p) * 40} w={560} h={330} r={60} style={{ background: th.surface, boxShadow: th.shadow, opacity: clamp(p * 1.6), transform: `scale(${0.92 + 0.08 * p})` }}>
              <Circ x={280} y={115} d={116} style={{ background: c.c, display: "flex", alignItems: "center", justifyContent: "center" }}>
                {c.icon === "up" ? (
                  <svg width={56} height={56} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round"><path d="M12 19V5M5 12l7-7 7 7" /></svg>
                ) : (
                  <div style={{ width: 50, height: 10, borderRadius: 5, background: "#fff" }} />
                )}
              </Circ>
              <Label x={280} y={240} size={40} weight={700} color={th.fg} w={520}>{c.title}</Label>
            </Box>
          </React.Fragment>
        );
      })}
      <Label x={CX} y={CY} size={90} weight={500} color={th.fgA(0.4)} w={200} style={{ opacity: A(lt, t2 - 0.2) }}>+</Label>
    </>
  );
};

// 15 -------------------------------------------------------------------- Threat
export const Threat = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const tj = tw(W, "judged", 0, 7);
  const shake = (rp(lt, tj - 0.1, tj + 0.1) - rp(lt, tj + 0.5, tj + 0.9)) * Math.sin(lt * 60) * 5;
  const hx = 1330, hy = 240, lx = 600, ly = 560;
  const pa = A(lt, 0.15, SN), pb = A(lt, 0.4, SN);
  const rings = [0, 1].map((i) => (lt * 0.62 + i / 2) % 1);
  return (
    <>
      <Box x={hx} y={hy + 110} w={520} h={22} r={11} style={{ background: th.fgA(0.25), transform: `scaleX(${pa})` }} />
      <Box x={lx} y={ly + 66} w={520} h={22} r={11} style={{ background: th.fgA(0.25), transform: `scaleX(${pb})` }} />
      <Circ x={hx} y={hy} d={190 * pa} style={{ background: th.fg }} />
      <Circ x={lx + shake} y={ly} d={110 * pb} style={{ background: th.blue }} />
      {rings.map((q, i) => {
        const x = lerp(hx, lx, q), y = lerp(hy, ly, q);
        return <Circ key={i} x={x} y={y} d={30 + 200 * q} style={{ border: `3px solid ${th.warm}`, opacity: (1 - q) * 0.8 * pb }} />;
      })}
      <Label x={hx} y={hy - 150} size={28} color={th.fgA(0.5)} w={300} style={{ opacity: pa, letterSpacing: "0.2em" }}>THEM</Label>
      <Label x={lx} y={ly + 130} size={28} color={th.fgA(0.5)} w={300} style={{ opacity: pb, letterSpacing: "0.2em" }}>YOU</Label>
    </>
  );
};

// 16 ---------------------------------------------------------------------- Flip
export const Flip = ({ lt, W }: VP) => {
  const th = useTheme();
  const ang = 180 * A(lt, 0.1, BN);
  const ts = tw(W, "same", 0, 3.0);
  const shift = A(lt, ts - 0.1, SM);
  const x = CX - 280 * shift;
  const t1 = tw(W, "intelligence", 0, 4.4);
  const t2 = tw(W, "presence", 0, 5.8);
  return (
    <>
      <div style={{ position: "absolute", left: x - 170, top: CY - 170, width: 340, height: 340, perspective: 1600 }}>
        <div style={{ width: "100%", height: "100%", position: "relative", transformStyle: "preserve-3d", transform: `rotateY(${ang}deg)` }}>
          <div style={{ position: "absolute", inset: 0, borderRadius: 76, background: th.fg, backfaceVisibility: "hidden", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <div style={{ width: 150, height: 150, borderRadius: 75, border: `10px solid ${th.bg}` }} />
          </div>
          <div style={{ position: "absolute", inset: 0, borderRadius: 76, background: th.surface, boxShadow: th.shadow, backfaceVisibility: "hidden", transform: "rotateY(180deg)", overflow: "hidden" }}>
            <Person x={170} y={176} s={210} color={th.blue} />
          </div>
        </div>
      </div>
      <Chip x={CX + 300} y={CY - 50} w={430} h={92} size={36} p={A(lt, t1 - 0.1, SN)} color={th.surface} tc={th.fg}  text="Same intelligence" />
      <Chip x={CX + 300} y={CY + 70} w={430} h={92} size={36} p={A(lt, t2 - 0.1, SN)} color={th.surface} tc={th.fg} text="Same presence" />
    </>
  );
};

// 17 ------------------------------------------------------------- Admissions
export const Admissions = ({ lt, S }: VP) => {
  const th = useTheme();
  const xs = [420, 960, 1500];
  const labels = ["Forgot a name", "Wrong recipient", "2 minutes late"];
  return (
    <>
      {xs.map((x, i) => {
        const t0 = S_(S, i, i * 4);
        const p = A(lt, t0 - 0.05, SN);
        const q = A(lt, t0 + 0.2, BN);
        return (
          <React.Fragment key={i}>
            <Box x={x} y={CY + (1 - p) * 60} w={450} h={350} r={56} style={{ background: th.surface, opacity: clamp(p * 1.6), transform: `scale(${0.92 + 0.08 * p})` }}>
              <Circ x={400} y={50} d={26 * q} style={{ background: th.warm, boxShadow: `0 0 20px ${th.warm}` }} />
              <div style={{ position: "absolute", left: 0, right: 0, top: 70, display: "flex", justifyContent: "center", transform: `scale(${q})` }}>
                {i === 0 && (
                  <div style={{ width: 230, height: 150, borderRadius: 30, background: th.fgA(0.12), position: "relative" }}>
                    <div style={{ position: "absolute", left: 28, top: 32, width: 90, height: 14, borderRadius: 7, background: th.fgA(0.4) }} />
                    <div style={{ position: "absolute", left: 28, top: 62, width: 60, height: 14, borderRadius: 7, background: th.fgA(0.25) }} />
                    <div style={{ position: "absolute", right: 26, top: 22, fontSize: 80, fontWeight: 700, color: th.blue }}>?</div>
                  </div>
                )}
                {i === 1 && (
                  <svg width={230} height={150} viewBox="0 0 230 150">
                    <rect x={4} y={4} width={222} height={142} rx={30} fill={th.fgA(0.12)} />
                    <path d="M24 34 L115 92 L206 34" fill="none" stroke={th.fgA(0.45)} strokeWidth={10} strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                )}
                {i === 2 && (
                  <div style={{ width: 150, height: 150, borderRadius: 75, border: `10px solid ${th.fgA(0.4)}`, position: "relative", boxSizing: "border-box" }}>
                    <div style={{ position: "absolute", left: 66, top: 22, width: 10, height: 52, borderRadius: 5, background: th.fg, transformOrigin: "5px 47px", transform: `rotate(${lt * 40}deg)` }} />
                    <div style={{ position: "absolute", left: 66, top: 44, width: 10, height: 30, borderRadius: 5, background: th.warm, transformOrigin: "5px 30px", transform: `rotate(${lt * 8 + 60}deg)` }} />
                  </div>
                )}
              </div>
              <Label x={225} y={282} size={34} weight={600} color={th.fgA(0.7)} w={420}>{labels[i]}</Label>
            </Box>
          </React.Fragment>
        );
      })}
    </>
  );
};

// 18 -------------------------------------------------------------------- Soften
export const Soften = ({ lt, W }: VP) => {
  const th = useTheme();
  const cols = 9, rows = 4, sz = 96, gap = 36;
  const ts = tw(W, "softens", 0, 1.3);
  const tl = tw(W, "lean", 0, 3.3);
  const soft = A(lt, ts - 0.1, SM);
  const lean = A(lt, tl - 0.1, SOFT);
  return (
    <>
      {Array.from({ length: cols * rows }).map((_, n) => {
        const c = n % cols, r = Math.floor(n / cols);
        const bx = CX + (c - (cols - 1) / 2) * (sz + gap), by = CY + (r - (rows - 1) / 2) * (sz + gap);
        const x = lerp(bx, CX + (bx - CX) * 0.8, lean), y = lerp(by, CY + (by - CY) * 0.8, lean);
        const p = A(lt, 0.05 + (c + r) * 0.03, SN);
        return (
          <Box key={n} x={x} y={y} w={sz * p} h={sz * p} r={14 + (sz / 2 - 14) * soft} style={{ background: th.fg, transform: `rotate(${(1 - soft) * 0}deg)`, opacity: 0.9 - 0.3 * soft }}>
            <div style={{ position: "absolute", inset: 0, borderRadius: "inherit", background: th.blue, opacity: lean * (0.6 + 0.4 * Math.sin(n)) * 0.9 }} />
          </Box>
        );
      })}
    </>
  );
};

// 19 -------------------------------------------------------------------- Status
export const Status = ({ lt, W }: VP) => {
  const th = useTheme();
  const barH = 440, fillH = barH * 0.78, bottom = CY + 240, top = bottom - barH;
  const tA = tw(W, "admission", 0, 1.5);
  const fall = 0.45;
  const u = clamp((lt - (tA + 0.1)) / fall);
  const land = lt - (tA + 0.1 + fall);
  const landY = bottom - fillH - 24;
  const te = tw(W, "earned", 0, 5.2);
  const warm = A(lt, te - 0.1, SOFT);
  const bump = land > 0 ? 1 + 0.25 * Math.max(0, Math.exp(-land * 9) * Math.cos(land * 28)) : 1;
  const grow = A(lt, 0.15, SOFT);
  return (
    <>
      <Box x={CX} y={(top + bottom) / 2} w={150} h={barH} r={75} style={{ background: th.fgA(0.12) }} />
      <div style={{ position: "absolute", left: CX - 75, top: bottom - fillH * grow, width: 150, height: fillH * grow, borderRadius: 75, background: th.blue, boxShadow: warm > 0.02 ? `0 0 ${70 * warm}px ${12 * warm}px ${th.warm}` : "none" }} />
      <div style={{ position: "absolute", left: CX - 75, top: bottom - fillH * grow, width: 150, height: fillH * grow, borderRadius: 75, background: `linear-gradient(0deg, transparent, ${th.warm})`, opacity: warm * 0.8 }} />
      <Label x={CX - 300} y={bottom - fillH + 20} size={32} weight={600} color={th.fgA(0.5)} w={260} style={{ opacity: grow, justifyContent: "flex-end" }}>Status</Label>
      {u > 0 && <Circ x={CX} y={land > 0 ? landY + 6 : -50 + (landY + 50) * u * u} d={46 * (land > 0 ? bump : 1)} style={{ background: th.warm, boxShadow: `0 0 26px ${th.warm}` }} />}
      {land > 0 && <Circ x={CX} y={landY + 6} d={50 + 200 * rp(land, 0, 0.8)} style={{ border: `3px solid ${th.warm}`, opacity: 1 - rp(land, 0, 0.8) }} />}
    </>
  );
};

// 20 ------------------------------------------------------------------- Battery
export const Battery = ({ lt, dur }: VP) => {
  const th = useTheme();
  const lvl = 1 - 0.9 * rp(lt, 0.5, dur - 0.7, eIO);
  const col = lvl > 0.45 ? th.blue : lvl > 0.2 ? th.warm : th.red;
  const p = A(lt, 0.1, SN);
  const bw = 580, bh = 250, pad = 24;
  return (
    <>
      <Label x={CX} y={CY - 190} size={30} color={th.fgA(0.5)} style={{ letterSpacing: "0.22em", opacity: p }}>ENERGY</Label>
      <Box x={CX} y={CY} w={bw} h={bh} r={76} style={{ border: `12px solid ${th.fg}`, transform: `scale(${p})`, opacity: clamp(p * 1.6) }} />
      <Box x={CX + bw / 2 + 24} y={CY} w={40} h={104} r={20} style={{ background: th.fg, transform: `scale(${p})`, opacity: clamp(p * 1.6) }} />
      <div style={{ position: "absolute", left: CX - bw / 2 + pad, top: CY - bh / 2 + pad, width: Math.max(pad * 2, (bw - pad * 2) * lvl), height: bh - pad * 2, borderRadius: 50, background: col, boxShadow: `0 0 50px ${col}`, opacity: clamp(p * 1.6) }} />
    </>
  );
};
