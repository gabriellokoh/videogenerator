import React from "react";
import { A, BN, Box, Check, Chip, Circ, clamp, Cross, eIO, eOut, fl, Glass, Label, lerp, Orb, Person, rp, S_, SM, SN, SOFT, useTheme } from "./lib";
import { tw, Wd } from "./data";

export type VP = { lt: number; dur: number; S: number[]; SE: number[]; W: Wd[] };
export const CX = 960;
export const CY = 410;

// travelling orb along a gentle arc, t0..t1
export const Flight = ({ lt, t0, t1, x0, y0, x1, y1, arc = 90, d = 46, fade = true }: any) => {
  const u = clamp((lt - t0) / (t1 - t0));
  if (u <= 0 || (u >= 1 && fade)) return null;
  const e = eIO(u);
  const x = lerp(x0, x1, e), y = lerp(y0, y1, e) - arc * Math.sin(Math.PI * e);
  return <Orb x={x} y={y} d={d * (0.8 + 0.2 * Math.sin(Math.PI * u))} style={{ opacity: u > 0.92 ? (1 - u) / 0.08 : 1 }} />;
};

const Av = ({ x, y, s = 170, color, lt, seed = 0, label, th, p = 1, op = 1 }: any) => {
  const f = fl(lt, seed, 5);
  return (
    <div style={{ opacity: clamp(p * 1.6) * op, transform: `translate(${f.x}px, ${f.y}px) scale(${0.9 + 0.1 * p})`, transformOrigin: `${x}px ${y}px` }}>
      <Person x={x} y={y} s={s} color={color} />
      {label && <Label x={x} y={y + s * 0.62} size={28} weight={600} color={th.fgA(0.55)} w={300}>{label}</Label>}
    </div>
  );
};

const MeterCard = ({ x, y, w = 520, label, v, color, p, th }: any) => (
  <Glass x={x} y={y + (1 - p) * 20} w={w} h={112} r={40} style={{ opacity: clamp(p * 1.6) }}>
    <div style={{ position: "absolute", left: 34, top: 20, fontSize: 24, fontWeight: 700, letterSpacing: "0.16em", color: th.fgA(0.5) }}>{label}</div>
    <div style={{ position: "absolute", left: 34, right: 34, top: 64, height: 22, borderRadius: 11, background: th.fgA(0.1) }} />
    <div style={{ position: "absolute", left: 34, top: 64, width: (w - 68) * v, height: 22, borderRadius: 11, background: color, boxShadow: `0 0 22px ${color}` }} />
  </Glass>
);

// 1 -------------------------------------------------------------- Assumption
export const Assumption = ({ lt, S }: VP) => {
  const th = useTheme();
  const times = [S_(S, 0, 0) + 0.9, S_(S, 0, 0) + 1.8, S_(S, 1, 3) + 0.4, S_(S, 2, 4) + 0.4, S_(S, 3, 6) + 0.4];
  const n = times.filter((t) => lt > t + 0.9).length;
  const v = 0.1 + 0.18 * n * 0.95;
  const p = A(lt, 0.1, SN);
  return (
    <>
      <MeterCard x={CX} y={230} label="LIKING" v={lerp(0.1, v, A(lt, times[Math.max(0, n - 1)] + 0.9, SM))} color={th.blue} p={A(lt, 0.2, SN)} th={th} />
      <Av x={480} y={470} color={th.blue} lt={lt} th={th} label="You" p={p} />
      <Av x={1440} y={470} color={th.gray} lt={lt} seed={2} th={th} label="Them" p={A(lt, 0.25, SN)} />
      <Box x={CX} y={500} w={620} h={0} r={0} style={{ borderTop: `4px dotted ${th.fgA(0.2)}` }} />
      {times.map((t, i) => <Flight key={i} lt={lt} t0={t} t1={t + 0.9} x0={560} y0={440} x1={1360} y1={440} arc={80 + 20 * (i % 2)} />)}
    </>
  );
};

// 2 ----------------------------------------------------------------- Distance
export const Distance = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const tA = tw(W, "automatically", 0, 3);
  const tD = tw(W, "distance", 0, S_(S, 2, 7) + 2.4);
  const drift = A(lt, tD - 0.2, SOFT);
  const rx = lerp(1440, 1640, drift);
  const flights = [S_(S, 0, 0) + 0.6, S_(S, 0, 0) + 1.9, S_(S, 1, 4) - 0.8];
  return (
    <>
      <MeterCard x={CX} y={230} label="LIKING" v={0.46} color={th.blue} p={A(lt, 0.1, SN)} th={th} />
      <Av x={480} y={470} color={th.blue} lt={lt} th={th} label="You" />
      <Av x={rx} y={470} color={th.gray} lt={lt} seed={2} th={th} label="Them" op={1 - 0.35 * drift} />
      <Box x={(480 + rx) / 2} y={500} w={Math.max(0, rx - 480 - 140)} h={0} r={0} style={{ borderTop: `4px dotted ${th.fgA(0.25)}` }} />
      {flights.map((t, i) => <Flight key={i} lt={lt} t0={t} t1={t + 0.9} x0={560} y0={440} x1={rx - 80} y1={440} arc={70} />)}
      <Chip x={CX} y={345} w={250} p={A(lt, tA - 0.1, SN)} glass tc={th.fg} text="No change" />
      <Chip x={CX + 40} y={620} w={270} p={A(lt, tD - 0.1, SN)} color={th.warm} text="Distance" />
    </>
  );
};

// 3 ------------------------------------------------------------------ Reverse
export const Reverse = ({ lt, W }: VP) => {
  const th = useTheme();
  const tf = tw(W, "small", 0, 2.6);
  const arrive = A(lt, tf + 0.9, SN);
  return (
    <>
      <MeterCard x={480} y={260} w={440} label="WARMTH & RESPECT" v={lerp(0.2, 0.88, A(lt, tf + 0.9, SM))} color={th.warm} p={A(lt, 0.1, SN)} th={th} />
      <Av x={480} y={470} color={th.blue} lt={lt} th={th} label="You" />
      <Av x={1440} y={470} color={th.gray} lt={lt} seed={2} th={th} label="Them" />
      <Flight lt={lt} t0={tf} t1={tf + 0.9} x0={1360} y0={440} x1={560} y1={440} arc={90} d={52} />
      <Circ x={480} y={440} d={320 * arrive} style={{ border: `4px solid ${th.warm}`, opacity: (1 - arrive) * 0.7 }} />
    </>
  );
};

// 4 -------------------------------------------------------------------- Title
export const Title = ({ lt, W }: VP) => {
  const th = useTheme();
  const t0 = tw(W, "this", 0, 0.05);
  const t1 = tw(W, "ben", 0, 1.0);
  const t2 = tw(W, "franklin", 0, 1.3);
  const t3 = tw(W, "effect", 0, 1.7);
  const word = (txt: string, t: number, color: string, wt: number) => {
    const p = A(lt, t - 0.05, SN), q = clamp(p);
    return <span style={{ display: "inline-block", opacity: clamp(p * 1.8), transform: `translateY(${(1 - p) * 50}px) scale(${0.94 + 0.06 * p})`, filter: `blur(${(1 - q) * 16}px)`, color, fontWeight: wt }}>{txt}</span>;
  };
  const kp = A(lt, t0 - 0.05, SM);
  const f = fl(lt, 1, 4);
  return (
    <div style={{ transform: `translate(${f.x}px, ${f.y}px)` }}>
      <Label x={CX} y={300} size={32} weight={600} color={th.fgA(0.55)} style={{ letterSpacing: "0.22em", opacity: clamp(kp * 1.6) }}>THIS IS KNOWN AS</Label>
      <div style={{ position: "absolute", left: 0, top: 350, width: 1920, display: "flex", flexDirection: "column", alignItems: "center", fontSize: 150, lineHeight: 1.04, letterSpacing: "-0.045em", whiteSpace: "nowrap" }}>
        <div style={{ display: "flex", gap: 36 }}>{word("The", t1 - 0.1, th.fgA(0.45), 500)}{word("Ben", t1, th.fg, 700)}{word("Franklin", t2, th.fg, 700)}</div>
        <div>{word("Effect", t3, th.blue, 700)}</div>
      </div>
    </div>
  );
};

// 5 ----------------------------------------------------------------- Assembly
export const Assembly = ({ lt, W }: VP) => {
  const th = useTheme();
  const tcold = tw(W, "cold", 0, 12);
  const chips: [string, number][] = [["Wealthy", tw(W, "wealthy", 0, 7)], ["Educated", tw(W, "educated", 0, 8.4)], ["Influential", tw(W, "influential", 0, 9.4)]];
  return (
    <>
      <Glass x={CX} y={430} w={1500} h={520} r={64} style={{ opacity: A(lt, 0.05, SN), transform: `scale(${0.96 + 0.04 * A(lt, 0.05, SN)})` }}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 36, textAlign: "center", fontSize: 26, fontWeight: 700, letterSpacing: "0.2em", color: th.fgA(0.5) }}>PENNSYLVANIA ASSEMBLY · 1730s</div>
      </Glass>
      <Av x={520} y={470} s={190} color={th.blue} lt={lt} th={th} label="Franklin" p={A(lt, 0.3, SN)} />
      <Av x={1230} y={470} s={190} color={th.gray} lt={lt} seed={3} th={th} label="Rival" p={A(lt, 0.4, SN)} />
      {chips.map(([txt, t], i) => <Chip key={txt} x={1540} y={360 + i * 80} w={250} h={56} size={26} p={A(lt, t - 0.1, SN)} color={th.fg} text={txt} />)}
      <Box x={875} y={500} w={400 * A(lt, tcold - 0.3, SM)} h={0} r={0} style={{ borderTop: `4px dotted ${th.fgA(0.3)}` }} />
      <Chip x={875} y={430} w={240} p={A(lt, tcold - 0.1, SN)} glass tc={th.fg} text="Cold & formal" size={24} h={50} />
    </>
  );
};

// 6 -------------------------------------------------------------------- Usual
export const Usual = ({ lt, W }: VP) => {
  const th = useTheme();
  const items: [string, number][] = [["Offer help", tw(W, "help", 0, 1.6)], ["Be useful", tw(W, "useful", 0, 2.6)], ["Prove his value", tw(W, "value", 0, 3.6)]];
  const tI = tw(W, "instead", 0, 5.8);
  const out = A(lt, tI - 0.1, SM);
  const ts = tw(W, "specific", 0, tI + 1.2);
  const ring = A(lt, ts - 0.4, SN);
  const xs = [560, 960, 1360];
  return (
    <>
      {items.map(([txt, t], i) => {
        const p = A(lt, t - 0.1, SN);
        const strike = rp(lt, tI - 0.1, tI + 0.4);
        return (
          <Glass key={txt} x={xs[i]} y={400 - 18 * out} w={360} h={130} r={44} style={{ opacity: clamp(p * 1.6) * (1 - 0.75 * out), transform: `scale(${(0.92 + 0.08 * p) * (1 - 0.06 * out)})`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 36, fontWeight: 700, color: th.fg }}>
            {txt}
            <div style={{ position: "absolute", left: 40, top: 65, height: 5, width: 280 * strike, borderRadius: 3, background: th.warm }} />
          </Glass>
        );
      })}
      <Circ x={CX} y={420} d={300 * ring} style={{ border: `6px solid ${th.blue}`, opacity: clamp(ring), boxShadow: `0 0 60px ${th.blue}` }} />
      <Circ x={CX} y={420} d={70 * ring} style={{ background: th.blue, opacity: clamp(ring) }} />
      <Chip x={CX} y={610} w={330} p={A(lt, ts - 0.1, SN)} color={th.blue} text="Something specific" />
    </>
  );
};

// 7 ---------------------------------------------------------------------- Book
const BookIcon = ({ x, y, s = 1, rot = -8 }: any) => (
  <div style={{ position: "absolute", left: x - 130 * s, top: y - 170 * s, width: 260 * s, height: 340 * s, transform: `rotate(${rot}deg)`, borderRadius: 36 * s, background: "linear-gradient(145deg,#FFB340,#FF375F)", boxShadow: "0 36px 70px rgba(255,55,95,0.3)" }}>
    <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: 36 * s, borderRadius: `${36 * s}px 0 0 ${36 * s}px`, background: "rgba(255,255,255,0.28)" }} />
    <div style={{ position: "absolute", left: 66 * s, top: 70 * s, width: 130 * s, height: 16 * s, borderRadius: 8 * s, background: "rgba(255,255,255,0.8)" }} />
    <div style={{ position: "absolute", left: 66 * s, top: 108 * s, width: 90 * s, height: 16 * s, borderRadius: 8 * s, background: "rgba(255,255,255,0.55)" }} />
  </div>
);
export const Book = ({ lt }: VP) => {
  const th = useTheme();
  const p = A(lt, 0.1, BN);
  const f = fl(lt, 2, 10);
  return (
    <>
      <Circ x={CX} y={400} d={460 * p} style={{ border: `3px solid ${th.warm}`, opacity: 0.35 * (0.6 + 0.4 * Math.sin(lt * 2)) }} />
      <div style={{ transform: `translate(${f.x}px, ${f.y}px) scale(${p})`, transformOrigin: `${CX}px 400px`, opacity: clamp(p * 1.6) }}><BookIcon x={CX} y={400} /></div>
      <Chip x={CX} y={650} w={240} p={A(lt, 0.6, SN)} glass tc={th.fg} text="Rare book" />
    </>
  );
};

// 8 --------------------------------------------------------------- NoteExchange
export const NoteExchange = ({ lt, W }: VP) => {
  const th = useTheme();
  const tn = tw(W, "sent", 0, 0.8);
  const tb = tw(W, "sent", 1, 4.2);
  const ta = tw(W, "agreed", 0, 3.4);
  const note = clamp((lt - tn) / 1.1), back = clamp((lt - tb) / 1.1);
  const nx = lerp(560, 1300, eIO(note)), ny = 380 - 90 * Math.sin(Math.PI * eIO(note));
  const bx = lerp(1710, 560, eIO(back)), by = 420 - 80 * Math.sin(Math.PI * eIO(back));
  return (
    <>
      <Av x={420} y={480} color={th.blue} lt={lt} th={th} label="Franklin" />
      <Av x={1440} y={480} color={th.gray} lt={lt} seed={2} th={th} label="Rival" />
      {note > 0 && note < 1 && (
        <Glass x={nx} y={ny} w={420} h={130} r={40} style={{ display: "flex", alignItems: "center", justifyContent: "center", textAlign: "center", padding: "0 26px", fontSize: 26, fontWeight: 600, color: th.fg, lineHeight: 1.2, transform: `rotate(${(1 - note) * -5}deg)` }}>May I borrow your book for a few days?</Glass>
      )}
      {note >= 1 && back <= 0 && <div style={{ opacity: 1 }}><BookIcon x={1710} y={420} s={0.55} rot={-6} /></div>}
      {back > 0 && <BookIcon x={bx} y={by} s={0.55} rot={-8 + 14 * back} />}
      <Chip x={1440} y={290} w={200} p={A(lt, ta - 0.1, SN)} color={th.green} icon={<Check s={24} />} text="Agreed" />
    </>
  );
};

// 9 --------------------------------------------------------------- ReturnThanks
export const ReturnThanks = ({ lt, W }: VP) => {
  const th = useTheme();
  const tt = tw(W, "thanks", 0, 2.6);
  const back = clamp((lt - 0.2) / 1.1);
  const bx = lerp(560, 1710, eIO(back)), by = 420 - 80 * Math.sin(Math.PI * eIO(back));
  const p = A(lt, tt - 0.4, BN);
  return (
    <>
      <Av x={420} y={480} color={th.blue} lt={lt} th={th} label="Franklin" />
      <Av x={1440} y={480} color={th.gray} lt={lt} seed={2} th={th} label="Rival" />
      <BookIcon x={bx} y={by} s={0.55} rot={-8 + 8 * back} />
      <Glass x={CX} y={300 - 10 * (1 - p)} w={380} h={120} r={40} style={{ opacity: clamp(p * 1.6), transform: `scale(${0.9 + 0.1 * p})`, display: "flex", alignItems: "center", justifyContent: "center", gap: 14, fontSize: 36, fontWeight: 700, color: th.fg }}>
        Thank you
        <div style={{ width: 34, height: 34, borderRadius: 17, background: th.warm, display: "flex", alignItems: "center", justifyContent: "center" }}><Check s={18} /></div>
      </Glass>
    </>
  );
};

// 10 -------------------------------------------------------------- Friendship
export const Friendship = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const tf = tw(W, "friendliness", 0, S_(S, 1, 4) + 1);
  const ts = tw(W, "softened", 0, S_(S, 2, 8));
  const ty = tw(W, "years", 0, S_(S, 3, 10) + 2);
  const close = A(lt, tf - 0.4, SOFT);
  const soft = A(lt, ts - 0.2, SM);
  const xa = lerp(480, 780, close), xb = lerp(1440, 1140, close);
  const ding = A(lt, ty - 0.6, SM);
  return (
    <>
      <Av x={xa} y={450} color={th.blue} lt={lt} th={th} label="Franklin" s={190} />
      <div style={{ opacity: 1 }}>
        <Av x={xb} y={450} color={th.gray} lt={lt} seed={2} th={th} label="Rival" s={190} />
        <div style={{ opacity: soft }}><Av x={xb} y={450} color={th.warm} lt={lt} seed={2} th={th} s={190} /></div>
      </div>
      <Box x={(xa + xb) / 2} y={490} w={Math.max(0, xb - xa - 160)} h={6} r={3} style={{ background: `linear-gradient(90deg, ${th.blue}, ${th.warm})`, opacity: soft }} />
      <Orb x={(xa + xb) / 2} y={490} d={34 + 8 * Math.sin(lt * 3)} style={{ opacity: soft }} />
      <Chip x={CX} y={260} w={330} p={A(lt, tf - 0.1, SN)} glass tc={th.fg} text="Unexpected friendliness" />
      {Array.from({ length: 7 }).map((_, i) => <Circ key={i} x={CX - 270 + i * 90} y={700} d={18 * clamp(ding * 3 - i * 0.4)} style={{ background: th.warm, opacity: 0.85 }} />)}
      <Label x={CX} y={744} size={24} weight={600} color={th.fgA(0.5)} w={500} style={{ opacity: ding, letterSpacing: "0.18em" }}>YEARS</Label>
    </>
  );
};

// 11 ---------------------------------------------------------------------- Quote
export const Quote = ({ lt }: VP) => {
  const th = useTheme();
  const p = A(lt, 0.1, SN);
  const f = fl(lt, 4, 6);
  return (
    <div style={{ transform: `translate(${f.x}px, ${f.y}px)` }}>
      <Glass x={CX} y={380} w={1100} h={400} r={72} style={{ opacity: clamp(p * 1.6), transform: `scale(${0.94 + 0.06 * p})` }}>
        <div style={{ position: "absolute", left: 70, top: 20, fontSize: 280, fontWeight: 800, lineHeight: 1, background: "linear-gradient(145deg,#0A84FF,#BF5AF2)", WebkitBackgroundClip: "text", color: "transparent" }}>“</div>
        <div style={{ position: "absolute", left: 100, bottom: 50, fontSize: 34, fontWeight: 700, color: th.fg }}>Benjamin Franklin</div>
        <div style={{ position: "absolute", right: 70, bottom: 56, fontSize: 24, fontWeight: 600, letterSpacing: "0.16em", color: th.fgA(0.45) }}>AN OLDER OBSERVATION</div>
      </Glass>
    </div>
  );
};

// 13 ------------------------------------------------------------- Timeline2
export const Timeline2 = ({ lt, W }: VP) => {
  const th = useTheme();
  const t69 = tw(W, "centuries", 0, 1.6);
  const x0 = 400, x1 = 1520, y = 420;
  const k = A(lt, 0.1, SOFT);
  const mv = A(lt, 0.4, SOFT);
  const arriveP = A(lt, t69 - 0.2, SN);
  return (
    <>
      <Box x={(x0 + x1) / 2} y={y} w={(x1 - x0) * k} h={8} r={4} style={{ background: th.fgA(0.15) }} />
      <Box x={x0 + (x1 - x0) * mv / 2} y={y} w={(x1 - x0) * mv} h={8} r={4} style={{ background: `linear-gradient(90deg, ${th.warm}, ${th.blue})`, boxShadow: `0 0 20px ${th.blue}` }} />
      <Circ x={x0} y={y} d={36 * k} style={{ background: th.warm }} />
      <Circ x={x1} y={y} d={36 * arriveP} style={{ background: th.blue, boxShadow: `0 0 30px ${th.blue}` }} />
      <Label x={x0} y={y + 64} size={34} weight={700} color={th.fg} w={300} style={{ opacity: k }}>1730s</Label>
      <Label x={x1} y={y + 64} size={34} weight={700} color={th.fg} w={300} style={{ opacity: arriveP }}>1969</Label>
      <Chip x={(x0 + x1) / 2} y={y - 90} w={360} p={A(lt, t69 - 0.2, SN)} glass tc={th.fg} text="200+ years later" />
    </>
  );
};

// 14 ----------------------------------------------------------- Participants
export const Participants = ({ lt, W }: VP) => {
  const th = useTheme();
  const tP = tw(W, "participants", 0, 1.6);
  const tM = tw(W, "money", 0, 3.4);
  const tD = tw(W, "divided", 0, 5.4);
  const N = 74;
  const split = A(lt, tD - 0.1, SOFT);
  const cols = [th.blue, th.warm, th.fgA(0.4)];
  return (
    <>
      {Array.from({ length: N }).map((_, n) => {
        const c = n % 10, r = Math.floor(n / 10);
        const gx = CX + (c - 4.5) * 78, gy = 420 + (r - 3.5) * 66;
        const g = n < 25 ? 0 : n < 50 ? 1 : 2;
        const idx = n < 25 ? n : n < 50 ? n - 25 : n - 50;
        const cxg = [520, 960, 1400][g];
        const sx = cxg + ((idx % 5) - 2) * 58, sy = 420 + (Math.floor(idx / 5) - 2) * 58;
        const x = lerp(gx, sx, split), y = lerp(gy, sy, split);
        const p = A(lt, tP - 0.1 + n * 0.012, SN);
        return (
          <React.Fragment key={n}>
            <Circ x={x} y={y} d={34 * p} style={{ background: th.fgA(0.18) }} />
            <Circ x={x} y={y} d={34 * p} style={{ background: cols[g], opacity: split }} />
          </React.Fragment>
        );
      })}
      <Chip x={CX} y={140} w={260} p={A(lt, tM - 0.1, SN)} color={th.warm} text="Won money" />
      {[0, 1, 2].map((i) => <Label key={i} x={[520, 960, 1400][i]} y={600} size={28} weight={700} color={th.fgA(0.6)} w={300} style={{ opacity: split }}>{["Group 1", "Group 2", "Group 3"][i]}</Label>)}
    </>
  );
};

// 15 ----------------------------------------------------------- ThreeGroups
export const ThreeGroups = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const xs = [420, 960, 1500];
  const titles = ["Asked personally", "Asked by a secretary", "Never asked"];
  const t0 = [S_(S, 0, 0), S_(S, 2, 10), S_(S, 3, 14)];
  const mT = S_(S, 4, 18);
  const lv = [A(lt, S_(S, 5, 22) + 0.4, SM) * 0.92, A(lt, S_(S, 6, 26) + 0.4, SM) * 0.24, A(lt, S_(S, 7, 29) + 0.4, SM) * 0.56];
  const own = A(lt, S_(S, 1, 5) + 0.6, SN);
  const hl = A(lt, S_(S, 8, 33), SM);
  return (
    <>
      {xs.map((x, i) => {
        const p = A(lt, t0[i] - 0.05, SN);
        const mp = A(lt, mT + i * 0.15, SN);
        const f = fl(lt, i * 2, 4);
        return (
          <React.Fragment key={i}>
            <div style={{ transform: `translate(${f.x}px, ${f.y}px)` }}>
              <Glass x={x} y={420 + (1 - p) * 40} w={440} h={500} r={60} style={{ opacity: clamp(p * 1.6), transform: `scale(${0.94 + 0.06 * p})`, boxShadow: `0 0 0 ${i === 0 ? 4 * hl : 0}px ${th.blue}, 0 0 0 1.5px rgba(29,29,31,0.10), 0 26px 70px rgba(60,70,140,0.18), inset 0 2px 0 rgba(255,255,255,0.95)` }}>
                <div style={{ position: "absolute", left: 0, right: 0, top: 32, textAlign: "center", fontSize: 30, fontWeight: 700, color: th.fg }}>{titles[i]}</div>
                <div style={{ position: "absolute", left: 220 - 100, top: 100, width: 200, height: 200 }}>
                  <Person x={100} y={110} s={150} color={i === 2 ? th.fgA(0.25) : i === 1 ? th.warm : th.blue} />
                </div>
                {i === 0 && <div style={{ position: "absolute", left: 40, top: 290, width: 360, height: 70, borderRadius: 35, background: th.fgA(0.08), display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, fontWeight: 600, color: th.fg, opacity: p }}>“Could you return the money?”</div>}
                {i === 1 && <div style={{ position: "absolute", left: 40, top: 290, width: 360, height: 70, borderRadius: 35, background: th.fgA(0.08), display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, fontWeight: 600, color: th.fg, opacity: p }}>“On behalf of the department”</div>}
                {i === 2 && <div style={{ position: "absolute", left: 40, top: 290, width: 360, height: 70, borderRadius: 35, border: `3px dashed ${th.fgA(0.25)}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, fontWeight: 600, color: th.fgA(0.5), opacity: p }}>No request</div>}
                {i === 0 && <div style={{ position: "absolute", left: 120, top: 372, width: 200, height: 40, borderRadius: 20, background: th.warm, color: "#fff", fontSize: 22, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", opacity: clamp(own * 1.6), transform: `scale(${own})` }}>His own funds</div>}
                <div style={{ position: "absolute", left: 40, right: 40, bottom: 42, opacity: mp }}>
                  <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: "0.16em", color: th.fgA(0.5), marginBottom: 10 }}>LIKED THE RESEARCHER</div>
                  <div style={{ height: 22, borderRadius: 11, background: th.fgA(0.1) }}>
                    <div style={{ width: `${lv[i] * 100}%`, height: "100%", borderRadius: 11, background: i === 0 ? th.blue : i === 1 ? th.warm : th.fgA(0.4), boxShadow: i === 0 ? `0 0 22px ${th.blue}` : "none" }} />
                  </div>
                </div>
              </Glass>
            </div>
          </React.Fragment>
        );
      })}
    </>
  );
};
