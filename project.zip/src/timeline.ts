import { SENTS, END, Wd, chunkSentence, tw } from "./data";
import { SCENES, SceneDef } from "./scenes";

export type Scene = {
  i: number; def: SceneDef; start: number; end: number;
  S: number[]; SE: number[]; W: Wd[]; // relative to scene start
};
export const TOTAL = END + 1.4; // seconds (video ends ~1.4s after the last word)

export const SC: Scene[] = SCENES.map((def, i) => {
  const first = SENTS[def.from];
  const nextFrom = i + 1 < SCENES.length ? SCENES[i + 1].from : SENTS.length;
  const start = i === 0 ? 0 : first[0].start;
  const end = i + 1 < SCENES.length ? SENTS[nextFrom][0].start : TOTAL;
  const sents = SENTS.slice(def.from, nextFrom);
  const S = sents.map((s) => s[0].start - start);
  const SE = sents.map((s) => s[s.length - 1].end - start);
  const W = sents.flat().map((w) => ({ text: w.text, start: w.start - start, end: w.end - start }));
  return { i, def, start, end, S, SE, W };
});

export type Chunk = { words: Wd[]; start: number; end: number; ex0: number; ex1: number; pos: "low" | "mid" };
export const CHUNKS: Chunk[] = (() => {
  const out: Chunk[] = [];
  for (const sc of SC) {
    if (sc.def.cap === "off") continue;
    const nextFrom = sc.i + 1 < SCENES.length ? SCENES[sc.i + 1].from : SENTS.length;
    const list: Wd[][] = [];
    for (const s of SENTS.slice(sc.def.from, nextFrom)) list.push(...chunkSentence(s));
    list.forEach((words, j) => {
      const start = words[0].start;
      const end = words[words.length - 1].end;
      const next = list[j + 1];
      let ex0 = next ? Math.min(end + 0.8, next[0].start - 0.2) : Math.min(end + 0.8, sc.end - 0.12);
      ex0 = Math.max(ex0, end - 0.02);
      out.push({ words, start, end, ex0, ex1: ex0 + 0.24, pos: sc.def.cap === "mid" ? "mid" : "low" });
    });
  }
  return out;
})();

export type Sfx = { at: number; kind: string; vol: number };
const DEFAULT_VOL: Record<string, number> = {
  whoosh: 0.26, pop: 0.3, tick: 0.28, click: 0.4, drop: 0.45, thud: 0.4, chime: 0.2, rise: 0.22,
};
export const SFX: Sfx[] = (() => {
  const out: Sfx[] = [];
  for (const sc of SC) {
    if (sc.i > 0) out.push({ at: sc.start - 0.08, kind: "whoosh", vol: DEFAULT_VOL.whoosh });
    for (const [when, kind, vol] of sc.def.fx ?? []) {
      let rel: number | null = null;
      if (typeof when === "number") rel = when;
      else {
        const m = /^(w|s):([^+]+)(?:\+(-?[\d.]+))?$/.exec(when);
        if (m) {
          const off = m[3] ? parseFloat(m[3]) : 0;
          if (m[1] === "w") {
            const t = tw(sc.W, m[2], 0, -1);
            if (t >= 0) rel = t + off;
          } else {
            const idx = parseInt(m[2], 10);
            if (sc.S[idx] !== undefined) rel = sc.S[idx] + off;
          }
        }
      }
      if (rel === null) continue;
      out.push({ at: sc.start + rel, kind, vol: vol ?? DEFAULT_VOL[kind] ?? 0.3 });
    }
  }
  return out.sort((a, b) => a.at - b.at);
})();

export const SFX_LEN: Record<string, number> = {
  whoosh: 1.0, pop: 0.3, tick: 0.12, click: 0.15, drop: 0.8, thud: 0.5, chime: 2.2, rise: 1.4,
};
