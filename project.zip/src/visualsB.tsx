import React from "react";
import { A, BN, Box, Check, Chip, Circ, clamp, Cross, eIO, eOut, fl, Glass, Label, lerp, Orb, Person, rp, S_, SM, SN, SOFT, spr, useTheme } from "./lib";
import { tw } from "./data";
import { VP, CX, CY, Flight } from "./visualsA";

// 16 --------------------------------------------------------- WhyDissonance
export const WhyDissonance = ({ lt, W }: VP) => {
  const th = useTheme();
  const td = tw(W, "dissonance", 0, 3.2);
  const p = A(lt, 0.1, BN);
  const f = fl(lt, 3, 8);
  return (
    <>
      <div style={{ transform: `translate(${f.x}px, ${f.y}px)` }}>
        <Glass x={CX} y={330} w={260} h={260} r={130} style={{ opacity: clamp(p * 1.6), transform: `scale(${p})`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 170, fontWeight: 800, color: th.blue }}>?</Glass>
      </div>
      <Chip x={CX} y={580} w={470} h={78} size={36} p={A(lt, td - 0.1, SN)} glass tc={th.fg} text="Cognitive dissonance" />
    </>
  );
};

// 17 -------------------------------------------------------------- Dissonance
export const Dissonance = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const tT = tw(W, "tension", 0, S_(S, 2, 12));
  const tAdj = tw(W, "adjusting", 0, S_(S, 3, 15));
  const tMaybe = tw(W, "maybe", 0, S_(S, 4, 18));
  const a = A(lt, 0.2, SN), b = A(lt, S_(S, 1, 7) - 0.1, SN);
  const tens = A(lt, tT - 0.2, SM) * (1 - A(lt, tAdj, SM));
  const res = A(lt, tMaybe - 0.1, SM);
  const L = 820, R = 1100, y = 400;
  let path = `M ${L} ${y}`;
  for (let i = 1; i <= 24; i++) {
    const x = lerp(L, R, i / 24);
    path += ` L ${x.toFixed(1)} ${(y + Math.sin(i * 1.9 + lt * 30) * 22 * tens * (i % 2 ? 1 : -1)).toFixed(1)}`;
  }
  return (
    <>
      <Glass x={540} y={y} w={520} h={190} r={52} style={{ opacity: clamp(a * 1.6), transform: `scale(${0.94 + 0.06 * a})`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 36, fontWeight: 700, color: th.fg }}>I helped this person</Glass>
      <Glass x={1380} y={y} w={520} h={190} r={52} style={{ opacity: clamp(b * 1.6), transform: `scale(${0.94 + 0.06 * b})`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 36, fontWeight: 700, color: th.fg }}>
        <div style={{ position: "absolute", inset: 0, borderRadius: "inherit", background: `linear-gradient(135deg, ${th.warm}, ${th.blue})`, opacity: res * 0.25 }} />
        <span style={{ position: "absolute", opacity: 1 - res }}>I don’t really like them</span>
        <span style={{ position: "absolute", opacity: res, color: th.blue }}>Maybe I like them</span>
      </Glass>
      <svg style={{ position: "absolute", left: 0, top: 0, opacity: clamp(Math.min(a, b) * 1.6) }} width={1920} height={1080}>
        <path d={path} fill="none" stroke={res > 0.5 ? th.blue : th.warm} strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      <Chip x={CX + 40} y={560} w={250} p={A(lt, tT - 0.1, SN) * (1 - res)} color={th.warm} text="Tension" />
      <Chip x={CX + 40} y={560} w={250} p={res} color={th.green} icon={<Check s={22} />} text="Resolved" />
    </>
  );
};

// 18 ------------------------------------------------------------------ Signal
export const Signal = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const tR = tw(W, "request", 0, S_(S, 1, 3));
  const tC = tw(W, "capable", 0, S_(S, 2, 6));
  const tT = tw(W, "trustworthy", 0, S_(S, 2, 8));
  const tL = tw(W, "liking", 0, S_(S, 3, 12));
  const ring = (i: number) => clamp((lt - (tR + i * 0.6)) / 1.6);
  const liked = A(lt, tL - 0.2, SM);
  return (
    <>
      <Av2 x={480} y={470} color={th.blue} lt={lt} th={th} label="Asks" />
      <Av2 x={1440} y={470} color={th.gray} lt={lt} th={th} seed={2} label="Asked" />
      {[0, 1, 2].map((i) => {
        const u = ring(i);
        if (u <= 0 || u >= 1) return null;
        return <Circ key={i} x={lerp(560, 1340, eOut(u))} y={450} d={60 + 90 * u} style={{ border: `4px solid ${th.blue}`, opacity: (1 - u) * 0.8 }} />;
      })}
      <Chip x={1440} y={290} w={230} p={A(lt, tC - 0.1, SN)} color={th.fg} text="Capable" />
      <Chip x={1440} y={355} w={250} p={A(lt, tT - 0.1, SN)} color={th.fg} text="Trustworthy" />
      <Circ x={1440} y={450} d={360 * liked} style={{ border: `5px solid ${th.warm}`, opacity: (1 - 0.4 * liked) * clamp(liked * 2) }} />
      <Glass x={CX} y={640} w={560} h={104} r={40} style={{ opacity: A(lt, tL - 0.3, SN) }}>
        <div style={{ position: "absolute", left: 32, top: 18, fontSize: 22, fontWeight: 700, letterSpacing: "0.16em", color: th.fgA(0.5) }}>LIKING</div>
        <div style={{ position: "absolute", left: 32, right: 32, top: 56, height: 20, borderRadius: 10, background: th.fgA(0.1) }} />
        <div style={{ position: "absolute", left: 32, top: 56, width: 496 * (0.3 + 0.6 * liked), height: 20, borderRadius: 10, background: th.warm, boxShadow: `0 0 20px ${th.warm}` }} />
      </Glass>
    </>
  );
};
const Av2 = ({ x, y, s = 170, color, lt, seed = 0, label, th }: any) => {
  const f = fl(lt, seed, 5);
  const p = A(lt, 0.15 + seed * 0.05, SN);
  return (
    <div style={{ opacity: clamp(p * 1.6), transform: `translate(${f.x}px, ${f.y}px) scale(${0.9 + 0.1 * p})`, transformOrigin: `${x}px ${y}px` }}>
      <Person x={x} y={y} s={s} color={color} />
      {label && <Label x={x} y={y + s * 0.62} size={28} weight={600} color={th.fgA(0.55)} w={300}>{label}</Label>}
    </div>
  );
};

// 19 ------------------------------------------------------------ SocialVsTrans
export const SocialVsTrans = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const tr = tw(W, "trust", 0, S_(S, 2, 15));
  const tc = tw(W, "collaborative", 0, S_(S, 3, 19));
  const pa = A(lt, 0.1, SN), pb = A(lt, S_(S, 0, 0) + 0.6, SN);
  const glow = A(lt, tc - 0.2, SM);
  const mk = (x: number, title: string, p: number, items: [string, number][], v: number, color: string, i: number) => (
    <Glass x={x} y={420} w={760} h={500} r={64} style={{ opacity: clamp(p * 1.6), transform: `scale(${0.95 + 0.05 * p})`, boxShadow: `0 0 0 ${i === 0 ? 4 * glow : 0}px ${th.blue}, 0 0 0 1.5px rgba(29,29,31,0.10), 0 26px 70px rgba(60,70,140,0.18), inset 0 2px 0 rgba(255,255,255,0.95)` }}>
      <div style={{ position: "absolute", left: 44, top: 36, fontSize: 36, fontWeight: 700, color: th.fg }}>{title}</div>
      {items.map(([txt, t], k) => {
        const q = A(lt, t - 0.1, SN);
        return <div key={txt} style={{ position: "absolute", left: 44, top: 120 + k * 78, height: 58, padding: "0 28px", borderRadius: 29, background: i === 0 ? th.blue : th.fgA(0.14), color: i === 0 ? "#fff" : th.fg, fontSize: 28, fontWeight: 600, display: "flex", alignItems: "center", opacity: clamp(q * 1.6), transform: `translateY(${(1 - q) * 14}px)` }}>{txt}</div>;
      })}
      <div style={{ position: "absolute", left: 44, right: 44, bottom: 64 }}>
        <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: "0.16em", color: th.fgA(0.5), marginBottom: 10 }}>WARMTH</div>
        <div style={{ height: 22, borderRadius: 11, background: th.fgA(0.1) }}><div style={{ width: `${v * 100}%`, height: "100%", borderRadius: 11, background: color, boxShadow: i === 0 ? `0 0 22px ${color}` : "none" }} /></div>
      </div>
    </Glass>
  );
  return (
    <>
      {mk(520, "Social request", pa, [["A quick opinion", tw(W, "opinion", 0, 2)], ["A book recommendation", tw(W, "recommendation", 0, 3)], ["Two minutes of advice", tw(W, "advice", 0, 4)]], A(lt, tr - 0.2, SM) * 0.45 + 0.4 * A(lt, tc, SM), th.warm, 0)}
      {mk(1400, "Transactional request", pb, [["Money", tw(W, "money", 0, 5.4)], ["A material favor", tw(W, "material", 0, 6.4)]], 0.22 * A(lt, tw(W, "money", 0, 5.4), SM), th.fgA(0.4), 1)}
    </>
  );
};

// ---------- balance scale ----------
const Scale = ({ lt, leftT, rightT, th, labels, extra }: any) => {
  const px = CX, py = 300, Lh = 400;
  const sum = (arr: number[]) => arr.reduce((a: number, t: number) => a + spr(lt - (t + 0.5), SOFT), 0);
  const angle = Math.max(-16, Math.min(16, -5.5 * (sum(leftT) - sum(rightT)))) + Math.sin(lt * 1.3) * 0.6;
  const rad = (angle * Math.PI) / 180;
  const ex = (s: number) => px + s * Lh * Math.cos(rad), ey = (s: number) => py + s * Lh * Math.sin(rad);
  const pans = [-1, 1].map((s) => ({ x: ex(s), y: ey(s) + 190, ex: ex(s), ey: ey(s) }));
  const orbs = (arr: number[], pan: any) => arr.map((t, i) => {
    const u = clamp((lt - t) / 0.5);
    if (u <= 0) return null;
    const fx = pan.x + ((i % 3) - 1) * 56, fy = pan.y - 36 - Math.floor(i / 3) * 46;
    return <Orb key={i} x={fx} y={lerp(fy - 300, fy, u * u)} d={44} style={{ opacity: clamp(u * 3) }} />;
  });
  return (
    <>
      <Box x={px} y={560} w={22} h={520} r={11} style={{ background: th.fgA(0.18) }} />
      <Box x={px} y={750} w={360} h={34} r={17} style={{ background: th.fgA(0.18) }} />
      <svg style={{ position: "absolute", left: 0, top: 0 }} width={1920} height={1080}>
        {pans.map((p, i) => (
          <g key={i} stroke={th.fgA(0.3)} strokeWidth={4} strokeLinecap="round">
            <line x1={p.ex} y1={p.ey} x2={p.x - 120} y2={p.y} /><line x1={p.ex} y1={p.ey} x2={p.x + 120} y2={p.y} />
          </g>
        ))}
      </svg>
      <Box x={px} y={py} w={Lh * 2 + 30} h={20} r={10} style={{ background: th.fg, transform: `rotate(${angle}deg)` }} />
      <Circ x={px} y={py} d={44} style={{ background: th.blue, boxShadow: `0 0 20px ${th.blue}` }} />
      {pans.map((p, i) => <Box key={i} x={p.x} y={p.y + 14} w={260} h={30} r={15} style={{ background: th.fgA(0.35) }} />)}
      {orbs(leftT, pans[0])}{orbs(rightT, pans[1])}
      <Label x={pans[0].x} y={pans[0].y + 70} size={28} weight={700} color={th.fgA(0.55)} w={300}>{labels[0]}</Label>
      <Label x={pans[1].x} y={pans[1].y + 70} size={28} weight={700} color={th.fgA(0.55)} w={300}>{labels[1]}</Label>
      {extra}
    </>
  );
};

// 21 ----------------------------------------------------------- ScalePleaser
export const ScalePleaser = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const left = [tw(W, "offers", 0, 3), tw(W, "stays", 0, 4), tw(W, "covers", 0, 5), tw(W, "never", 0, 6.2), S_(S, 1, 9) + 0.2, S_(S, 2, 12) + 0.4];
  const tg = tw(W, "generous", 0, S_(S, 1, 9) + 0.8), ti = tw(W, "invisible", 0, S_(S, 2, 12) + 1.2), to = tw(W, "onesided", 0, S_(S, 3, 17));
  return (
    <Scale lt={lt} leftT={left} rightT={[]} th={th} labels={["Gives", "Receives"]} extra={
      <>
        <Chip x={CX} y={150} w={300} p={A(lt, tg - 0.1, SN)} glass tc={th.fg} text="Looks generous" />
        <Chip x={CX - 460} y={150} w={250} p={A(lt, ti - 0.1, SN)} color={th.fgA(0.55)} text="Invisible" />
        <Chip x={CX + 460} y={150} w={250} p={A(lt, to - 0.1, SN)} color={th.warm} text="One-sided" />
      </>
    } />
  );
};

// 22 --------------------------------------------------------- BubblesIntro
export const BubblesIntro = ({ lt }: VP) => {
  const th = useTheme();
  const p = A(lt, 0.2, SN);
  return (
    <>
      <Av2 x={720} y={470} color={th.blue} lt={lt} th={th} s={200} />
      <Glass x={1130} y={360} w={340} h={130} r={65} style={{ opacity: clamp(p * 1.6), transform: `scale(${0.85 + 0.15 * p})` }}>
        <div style={{ display: "flex", gap: 20, height: "100%", alignItems: "center", justifyContent: "center" }}>
          {[0, 1, 2].map((i) => <div key={i} style={{ width: 30, height: 30, borderRadius: 15, background: i === 1 ? th.blue : th.fgA(0.4), transform: `translateY(${-14 * Math.max(0, Math.sin(lt * 5 - i * 0.7))}px)` }} />)}
        </div>
      </Glass>
    </>
  );
};

// 23 ----------------------------------------------------------------- Bubbles
export const Bubbles = ({ lt, S }: VP) => {
  const th = useTheme();
  const msgs = ["Can I get your take on this decision?", "Have you read anything good on this topic lately?", "Got two minutes to look at this with me?"];
  return (
    <>
      {msgs.map((m, i) => {
        const t = S_(S, i, i * 3);
        const typing = clamp((lt - (t - 0.5)) / 0.3) * (1 - clamp((lt - (t + 0.15)) / 0.2));
        const p = A(lt, t + 0.1, SN);
        const y = 290 + i * 150;
        return (
          <React.Fragment key={i}>
            <Glass x={760} y={y} w={210} h={90} r={45} style={{ opacity: typing }}>
              <div style={{ display: "flex", gap: 14, height: "100%", alignItems: "center", justifyContent: "center" }}>
                {[0, 1, 2].map((k) => <div key={k} style={{ width: 20, height: 20, borderRadius: 10, background: th.fgA(0.45), transform: `translateY(${-9 * Math.max(0, Math.sin(lt * 7 - k * 0.7))}px)` }} />)}
              </div>
            </Glass>
            <Box x={1000 + (1 - p) * 40} y={y} w={1180} h={100} r={50} style={{ background: "linear-gradient(135deg,#0A84FF,#5E5CE6)", color: "#fff", fontSize: 38, fontWeight: 600, display: "flex", alignItems: "center", justifyContent: "center", opacity: clamp(p * 1.6), transform: `scale(${0.94 + 0.06 * p})`, boxShadow: "0 18px 40px rgba(10,132,255,0.28)" }}>{m}</Box>
          </React.Fragment>
        );
      })}
    </>
  );
};

// 24 ---------------------------------------------------------- ScaleBalance
export const ScaleBalance = ({ lt, S }: VP) => {
  const th = useTheme();
  const left = [-3, -2.6, -2.2, -1.8, -1.4, -1];
  const right = [S_(S, 0, 4) + 0.9, S_(S, 0, 4) + 2.6, S_(S, 1, 6) + 0.6, S_(S, 1, 6) + 1.8, S_(S, 1, 6) + 3.0, S_(S, 1, 6) + 4.2];
  return (
    <Scale lt={lt + 3.2} leftT={left.map((t) => t + 3.2)} rightT={right.map((t) => t + 3.2)} th={th} labels={["You", "Them"]} extra={
      <Chip x={CX} y={150} w={300} p={A(lt, S_(S, 1, 6) + 3.4, SN)} color={th.green} icon={<Check s={22} />} text="Balanced" />
    } />
  );
};

// 25 -------------------------------------------------------------- Calibration2
export const Calibration2 = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const x0 = 380, x1 = 1540, y = 400;
  const tW = tw(W, "works", 0, 2.4), tK = tw(W, "weakens", 0, S_(S, 1, 7)), tB = tw(W, "burden", 0, S_(S, 2, 11));
  const p = A(lt, 0.1, SN);
  const sweep = 0.5 + 0.22 * Math.sin(lt * 2.6) * (1 - rp(lt, tW - 0.3, tW + 0.2));
  const good = A(lt, tW, SN), heavy = A(lt, tK, SN);
  const pos = lt < tW ? sweep : lerp(lerp(0.5, 0.14, good), 0.86, heavy);
  const zone = A(lt, tW, SM) * (1 - A(lt, tK, SM));
  return (
    <>
      <Glass x={CX} y={y} w={1320} h={260} r={70} style={{ opacity: clamp(p * 1.6) }}>
        <div style={{ position: "absolute", left: 60, top: 36, fontSize: 24, fontWeight: 700, letterSpacing: "0.16em", color: th.fgA(0.5) }}>SIZE OF THE REQUEST</div>
        <div style={{ position: "absolute", left: 60, right: 60, top: 130, height: 26, borderRadius: 13, background: `linear-gradient(90deg, ${th.blue}, ${th.warm})` }} />
        <div style={{ position: "absolute", left: 60, top: 112, width: 300, height: 62, borderRadius: 31, border: `4px solid ${th.blue}`, background: "rgba(10,132,255,0.12)", opacity: zone }} />
        <div style={{ position: "absolute", left: 60, top: 200, fontSize: 24, fontWeight: 600, color: th.fgA(0.55) }}>Low cost</div>
        <div style={{ position: "absolute", right: 60, top: 200, fontSize: 24, fontWeight: 600, color: th.fgA(0.55) }}>Heavy</div>
      </Glass>
      <Circ x={x0 + (x1 - x0) * pos} y={y + 5} d={76} style={{ background: "#fff", boxShadow: "0 12px 34px rgba(0,0,0,0.28)" }} />
      <Chip x={x0 + 200} y={y - 190} w={260} p={A(lt, tW - 0.1, SN) * (1 - A(lt, tB - 0.1, SM))} color={th.blue} text="Invitation" />
      <Chip x={x1 - 160} y={y - 190} w={240} p={A(lt, tB - 0.1, SN)} color={th.warm} text="Burden" />
    </>
  );
};

// 26 ------------------------------------------------------------- Frictionless
const AppTile = ({ x, y, c1, c2, dull }: any) => (
  <Box x={x} y={y} w={132} h={132} r={38} style={{ background: "#D1D1D6", boxShadow: "0 18px 40px rgba(60,70,140,0.18)" }}>
    <div style={{ position: "absolute", inset: 0, borderRadius: "inherit", background: `linear-gradient(145deg, ${c1}, ${c2})`, opacity: 1 - dull }} />
    <div style={{ position: "absolute", left: 34, top: 34, width: 64, height: 64, borderRadius: 22, background: "rgba(255,255,255,0.35)" }} />
  </Box>
);
export const Frictionless = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const tF = tw(W, "friction", 0, 2.6);
  const tD = tw(W, "dull", 0, S_(S, 2, 12));
  const dull = A(lt, tD - 0.4, SOFT);
  const speed = lerp(260, 30, dull);
  const base: [string, string][] = [["#0A84FF", "#5E5CE6"], ["#FF9F0A", "#FF375F"], ["#30D158", "#2DD4BF"], ["#BF5AF2", "#5E5CE6"], ["#64D2FF", "#0A84FF"], ["#FFD60A", "#FF9F0A"]];
  const pal = [...base, ...base.slice(0, 3)];
  const off = lt * speed - 0.5 * (260 - speed) * Math.min(lt, tD);
  const span = 9 * 230;
  return (
    <>
      {pal.map((c, i) => {
        const x = ((((i * 230 + off) % span) + span) % span) - 120 + 60;
        return <AppTile key={i} x={x + 120} y={420} c1={c[0]} c2={c[1]} dull={dull} />;
      })}
      <Chip x={CX} y={230} w={300} p={A(lt, tF - 0.1, SN)} glass tc={th.fg} text="Zero friction" />
      <Chip x={CX - 300} y={620} w={200} h={52} size={24} p={A(lt, tw(W, "apps", 0, 4) - 0.1, SN)} color={th.fg} text="Apps" />
      <Chip x={CX} y={620} w={200} h={52} size={24} p={A(lt, tw(W, "tools", 0, 5) - 0.1, SN)} color={th.fg} text="Tools" />
      <Chip x={CX + 300} y={620} w={200} h={52} size={24} p={A(lt, tw(W, "systems", 0, 5.6) - 0.1, SN)} color={th.fg} text="Systems" />
      <Chip x={CX} y={700} w={420} p={A(lt, tD - 0.1, SN)} color={th.warm} text="Duller sensitivity" />
    </>
  );
};

// 27 -------------------------------------------------------------------- Mutual
export const Mutual = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const tM = tw(W, "mutual", 0, 2.2);
  const tC = tw(W, "confidence", 0, S_(S, 1, 5)), tO = tw(W, "openness", 0, S_(S, 1, 6));
  const a = A(lt, tM - 0.8, SM);
  const orbs = [0, 1, 2, 3].map((i) => {
    const t0 = tM - 0.6 + i * 1.2;
    return <Flight key={i} lt={lt} t0={t0} t1={t0 + 1.0} x0={i % 2 ? 1360 : 560} y0={450} x1={i % 2 ? 560 : 1360} y1={450} arc={i % 2 ? -70 : 70} />;
  });
  return (
    <>
      <Av2 x={480} y={470} color={th.blue} lt={lt} th={th} />
      <Av2 x={1440} y={470} color={th.warm} lt={lt} th={th} seed={2} />
      <Box x={CX} y={500} w={780 * a} h={6} r={3} style={{ background: `linear-gradient(90deg, ${th.blue}, ${th.warm})`, boxShadow: `0 0 20px ${th.blue}` }} />
      {orbs}
      <Chip x={CX} y={250} w={420} p={A(lt, tM - 0.1, SN)} glass tc={th.fg} text="Small mutual investments" />
      <Chip x={480} y={290} w={230} p={A(lt, tC - 0.1, SN)} color={th.blue} text="Confidence" />
      <Chip x={1440} y={290} w={210} p={A(lt, tO - 0.1, SN)} color={th.warm} text="Openness" />
    </>
  );
};

// 28 ----------------------------------------------------------------- DontNeed
export const DontNeed = ({ lt, S }: VP) => {
  const th = useTheme();
  const items = ["Significant favors", "Constant help"];
  return (
    <>
      {items.map((txt, i) => {
        const p = A(lt, S_(S, i, i * 3.2) - 0.05, SN);
        const x = 560 + i * 800;
        const f = fl(lt, i * 3, 4);
        return (
          <div key={i} style={{ transform: `translate(${f.x}px, ${f.y}px)` }}>
            <Glass x={x} y={400} w={660} h={190} r={64} style={{ opacity: clamp(p * 1.6), transform: `scale(${0.94 + 0.06 * p})`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 46, fontWeight: 700, color: th.fgA(0.55) }}>
              {txt}
              <div style={{ position: "absolute", left: 70, right: 70, top: 93, height: 6, borderRadius: 3, background: th.red, transform: `scaleX(${A(lt, S_(S, i, 3) + 0.5, SN)})`, transformOrigin: "0 50%" }} />
            </Glass>
            <Circ x={x + 290} y={330} d={84 * A(lt, S_(S, i, 3) + 0.4, BN)} style={{ background: th.red, display: "flex", alignItems: "center", justifyContent: "center" }}><Cross s={40} /></Circ>
          </div>
        );
      })}
    </>
  );
};

// 29 ------------------------------------------------------------------ LetHelp
export const LetHelp = ({ lt, W }: VP) => {
  const th = useTheme();
  const tH = tw(W, "help", 1, 8);
  const arrive = A(lt, tH + 0.5, SN);
  const f = fl(lt, 5, 6);
  return (
    <>
      <div style={{ transform: `translate(${f.x}px, ${f.y}px)` }}><Av2 x={CX} y={420} s={250} color={th.blue} lt={lt} th={th} /></div>
      <Circ x={CX} y={400} d={460 * arrive} style={{ border: `5px solid ${th.warm}`, opacity: (1 - arrive) * 0.7 }} />
      <Flight lt={lt} t0={tH - 0.4} t1={tH + 0.6} x0={1500} y0={330} x1={CX + 90} y1={420} arc={100} d={58} />
    </>
  );
};

// 30 ----------------------------------------------------------------- Closest
export const Closest = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const tAlso = tw(W, "also", 0, S_(S, 1, 6) + 3);
  const n = 5;
  const pos = Array.from({ length: n }).map((_, i) => ({ x: 360 + i * 300, y: i % 2 ? 250 : 300 }));
  const cx = CX, cy = 560;
  return (
    <>
      {pos.map((p, i) => {
        const a = A(lt, 0.2 + i * 0.2, SN);
        return (
          <React.Fragment key={i}>
            <Box x={(p.x + cx) / 2} y={(p.y + cy) / 2} w={Math.hypot(p.x - cx, p.y - cy) * a} h={4} r={2} style={{ background: th.fgA(0.15), transform: `rotate(${Math.atan2(cy - p.y, cx - p.x)}rad)` }} />
            <div style={{ opacity: clamp(a * 1.6), transform: `scale(${0.9 + 0.1 * a})`, transformOrigin: `${p.x}px ${p.y}px` }}><Person x={p.x} y={p.y} s={110} color={[th.blue, th.warm, th.gray, th.blue, th.warm][i]} /></div>
            <Flight lt={lt} t0={S_(S, 1, 6) + 0.2 + i * 0.35} t1={S_(S, 1, 6) + 1.2 + i * 0.35} x0={cx} y0={cy - 20} x1={p.x} y1={p.y + 40} arc={-40} d={34} />
            <Flight lt={lt} t0={tAlso + 0.1 + i * 0.3} t1={tAlso + 1.1 + i * 0.3} x0={p.x} y0={p.y + 40} x1={cx} y1={cy - 20} arc={40} d={34} />
          </React.Fragment>
        );
      })}
      <div style={{ opacity: A(lt, 0.1, SN) }}><Person x={cx} y={cy + 10} s={170} color={th.fg} /></div>
      <Label x={cx} y={cy + 130} size={26} weight={700} color={th.fgA(0.5)} w={300}>You</Label>
    </>
  );
};

// 31 ---------------------------------------------------------------- Comments2
export const Comments2 = ({ lt, W }: VP) => {
  const th = useTheme();
  const p = A(lt, 0.1, BN);
  const f = fl(lt, 6, 6);
  return (
    <div style={{ transform: `translate(${f.x}px, ${f.y}px)` }}>
      <Glass x={CX} y={400} w={600} h={250} r={90} style={{ transform: `scale(${p})`, opacity: clamp(p * 1.6) }}>
        <div style={{ display: "flex", gap: 22, height: "100%", alignItems: "center", justifyContent: "center" }}>
          {[0, 1, 2].map((i) => <div key={i} style={{ width: 40, height: 40, borderRadius: 20, background: i === 1 ? th.blue : th.fgA(0.4), transform: `translateY(${-22 * Math.max(0, Math.sin(lt * 5 - i * 0.7))}px)` }} />)}
        </div>
      </Glass>
      <Circ x={CX - 220} y={560} d={46 * p} style={{ background: "rgba(255,255,255,0.7)", boxShadow: th.shadow }} />
      <Circ x={CX - 262} y={606} d={24 * p} style={{ background: "rgba(255,255,255,0.7)", boxShadow: th.shadow }} />
      <Label x={CX} y={660} size={36} weight={700} color={th.fgA(0.5)} style={{ letterSpacing: "0.2em", opacity: A(lt, 0.5) }}>COMMENTS</Label>
    </div>
  );
};
