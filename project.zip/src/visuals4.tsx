import React from "react";
import { A, BN, Box, Check, Circ, clamp, Cross, eIO, eOut, eStd, Label, lerp, rnd, rp, SM, SN, SOFT, useTheme } from "./lib";
import { tw } from "./data";
import { VP, CX, CY, Person } from "./visuals1";

const S_ = (S: number[], k: number, fb: number) => (S[k] !== undefined ? S[k] : fb);
const Chip = ({ x, y, w, h = 56, p, color, text, icon, tc = "#fff", size = 28 }: any) => (
  <Box x={x} y={y + (1 - p) * 16} w={w} h={h} r={h / 2} style={{ background: color, opacity: clamp(p * 1.6), display: "flex", alignItems: "center", justifyContent: "center", gap: 10, color: tc, fontSize: size, fontWeight: 600, whiteSpace: "nowrap" }}>
    {icon}
    {text}
  </Box>
);

// 21 ------------------------------------------------------------------ RealBlob
export const RealBlob = ({ lt, S }: VP) => {
  const th = useTheme();
  const ring = A(lt, 0.1, SN);
  const fade = A(lt, S_(S, 1, 2.6) - 0.1, SM);
  const blob = A(lt, S_(S, 2, 5.2) - 0.1, SOFT);
  const pts: string[] = [];
  const N = 120;
  for (let i = 0; i < N; i++) {
    const a = (i / N) * Math.PI * 2;
    const r = 176 * (1 + 0.07 * Math.sin(3 * a + lt * 1.1) + 0.05 * Math.sin(5 * a - lt * 0.8 + 2) + 0.035 * Math.sin(2 * a + lt * 0.6 + 1));
    pts.push(`${i === 0 ? "M" : "L"}${(380 + Math.cos(a) * r).toFixed(1)} ${(380 + Math.sin(a) * r).toFixed(1)}`);
  }
  return (
    <>
      <Circ x={CX} y={CY} d={360 * ring} style={{ border: `${10 - 6 * fade}px solid ${th.fg}`, opacity: (1 - 0.82 * fade) * clamp(ring * 1.6), transform: `scale(${1 - 0.06 * fade})` }} />
      <svg style={{ position: "absolute", left: CX - 380, top: CY - 380, opacity: blob, transform: `scale(${0.7 + 0.3 * blob})`, transformOrigin: "380px 380px" }} width={760} height={760}>
        <defs>
          <linearGradient id="bg1" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={th.warm} />
            <stop offset="100%" stopColor={th.blue} />
          </linearGradient>
          <filter id="gl1" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="28" /></filter>
        </defs>
        <path d={pts.join(" ") + "Z"} fill="url(#bg1)" filter="url(#gl1)" opacity={0.55} />
        <path d={pts.join(" ") + "Z"} fill="url(#bg1)" />
      </svg>
    </>
  );
};

// 22 -------------------------------------------------------------------- Layers
export const Layers = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const names = ["Likability", "Status", "Competence"];
  const spread = A(lt, 0.25, SN);
  const tc = tw(W, "competence", 0, S_(S, 1, 3) + 1.5);
  const hi = A(lt, tc - 0.1, SN);
  const tk = tw(W, "works", 0, tc + 2);
  const fall = 0.45;
  const u = clamp((lt - (tk - 0.2)) / fall);
  const land = lt - (tk - 0.2 + fall);
  const baseY = CY + 140;
  const ys = [0, 1, 2].map((i) => lerp(baseY + (i - 2) * 22 + 30, baseY + (i - 2) * 150, spread));
  return (
    <>
      {ys.map((y, i) => (
        <Box key={i} x={CX} y={y} w={760} h={110} r={40} style={{ background: i === 2 ? th.fgA(0.16) : th.surface, boxShadow: th.shadow, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 38, fontWeight: 600, color: i === 2 ? th.bg : th.fgA(0.55), opacity: clamp(A(lt, 0.1 + (2 - i) * 0.1, SN) * 1.6) }}>
          {i === 2 && <div style={{ position: "absolute", inset: 0, borderRadius: "inherit", background: th.fgA(0.12) }} />}
          {i === 2 && <div style={{ position: "absolute", inset: 0, borderRadius: "inherit", background: th.blue, opacity: hi }} />}
          <span style={{ position: "relative", color: i === 2 ? (hi > 0.5 ? "#fff" : th.fgA(0.55)) : th.fgA(0.55) }}>{names[i]}</span>
        </Box>
      ))}
      {u > 0 && <Circ x={1150} y={land > 0 ? ys[2] - 55 - 4 : -50 + (ys[2] - 55 + 50) * u * u} d={46} style={{ background: th.warm, boxShadow: `0 0 26px ${th.warm}` }} />}
      {land > 0 && <Circ x={1150} y={ys[2] - 59} d={50 + 200 * rp(land, 0, 0.7)} style={{ border: `3px solid ${th.warm}`, opacity: 1 - rp(land, 0, 0.7) }} />}
    </>
  );
};

// 23 ------------------------------------------------------------------- Pillars
export const Pillars = ({ lt, W }: VP) => {
  const th = useTheme();
  const ground = 640;
  const tL = tw(W, "mistake", 0, 2.0);
  const tR = tw(W, "flaw", 0, 7.0);
  const tP = tw(W, "proof", 0, tR + 2);
  const fall = 0.45;
  const pl = A(lt, 0.1, SN), pr = A(lt, 0.3, SN);
  const lu = clamp((lt - tL) / fall), ru = clamp((lt - tR) / fall);
  const ll = lt - (tL + fall), rl = lt - (tR + fall);
  const lh = 140, rh = 350;
  const badgeL = A(lt, tL + fall, BN), badgeR = A(lt, tR + fall, BN);
  const shake = rl > -9 && ll > 0 ? Math.sin(ll * 50) * 6 * Math.exp(-ll * 6) : 0;
  return (
    <>
      <Box x={CX} y={ground + 5} w={1400 * pl} h={8} r={4} style={{ background: th.fgA(0.2) }} />
      <Box x={640 + shake} y={ground - (lh * pl) / 2} w={170} h={lh * pl} r={40} style={{ background: th.fgA(0.35), opacity: 1 - 0.4 * badgeL }} />
      <Box x={1280} y={ground - (rh * pr) / 2} w={170} h={rh * pr} r={40} style={{ background: th.blue, boxShadow: rl > 0 ? `0 0 ${60 * badgeR}px ${th.blue}` : "none" }} />
      <Label x={640} y={ground + 62} size={36} weight={600} color={th.fgA(0.6)} w={400} style={{ opacity: pl }}>Low status</Label>
      <Label x={1280} y={ground + 62} size={36} weight={600} color={th.fgA(0.6)} w={400} style={{ opacity: pr }}>Capable</Label>
      {lu > 0 && ll < 0 && <Circ x={640} y={-50 + (ground - lh - 24 + 50) * lu * lu} d={44} style={{ background: th.warm }} />}
      {ll > 0 && <Circ x={640} y={ground - lh - 24} d={44} style={{ background: th.warm, opacity: 1 - 0.5 * badgeL }} />}
      {ru > 0 && rl < 0 && <Circ x={1280} y={-50 + (ground - rh - 24 + 50) * ru * ru} d={44} style={{ background: th.warm }} />}
      {rl > 0 && <Circ x={1280} y={ground - rh - 24} d={44} style={{ background: th.warm }} />}
      <Circ x={640} y={ground - lh - 110} d={78 * badgeL} style={{ background: th.red, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <Cross s={38} />
      </Circ>
      <Circ x={1280} y={ground - rh - 110} d={78 * badgeR} style={{ background: th.green, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <Check s={40} />
      </Circ>
      <Chip x={1280 + 230} y={ground - rh - 90} w={250} h={60} p={A(lt, tP - 0.1, SN)} color={th.fgA(0.12)} tc={th.fg} text="Social proof" />
    </>
  );
};

// 24 ----------------------------------------------------------------- Humanize
export const Humanize = ({ lt, W }: VP) => {
  const th = useTheme();
  const ts = tw(W, "self", 0, 2.0);
  const tq = tw(W, "question", 0, 4.6);
  const th_ = tw(W, "humanizes", 0, 6.6);
  const p = A(lt, 0.1, SN);
  const bub = A(lt, ts - 0.1, BN);
  const ok = A(lt, tq - 0.1, SN);
  const warm = A(lt, th_ - 0.1, SOFT);
  return (
    <>
      <Circ x={CX} y={CY} d={620} style={{ background: `radial-gradient(circle, ${th.warm} 0%, transparent 68%)`, opacity: 0.55 * warm }} />
      <Circ x={CX} y={CY} d={430 * ok} style={{ border: `7px solid ${th.green}`, opacity: ok * (1 - 0.35 * warm) }} />
      <div style={{ opacity: clamp(p * 1.6), transform: `scale(${0.9 + 0.1 * p})`, transformOrigin: `${CX}px ${CY}px` }}>
        <Person x={CX} y={CY + 6} s={300} color={th.blue} />
      </div>
      <Box x={CX + 250} y={CY - 150 - (1 - bub) * 20} w={210} h={90} r={45} style={{ background: th.warm, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 44, fontWeight: 600, opacity: clamp(bub * 1.6) * (1 - 0.7 * ok), transform: `scale(${bub}) rotate(${Math.sin(lt * 8) * 3 * (1 - rp(lt, ts + 0.6, ts + 1.2))}deg)` }}>
        oops
      </Box>
      <Circ x={CX + 160} y={CY - 90} d={18 * bub} style={{ background: th.warm }} />
      <Circ x={CX + 135} y={CY - 58} d={11 * bub} style={{ background: th.warm }} />
      <Circ x={CX + 160} y={CY - 160} d={64 * ok} style={{ background: th.green, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <Check s={32} />
      </Circ>
    </>
  );
};

// 25 -------------------------------------------------------------------- Toggle
export const Toggle = ({ lt }: VP) => {
  const th = useTheme();
  const p = A(lt, 0.05, SN);
  const on = A(lt, 0.38, SN);
  const w = 360, h = 210;
  return (
    <>
      <Box x={CX} y={CY} w={w * p} h={h * p} r={h / 2} style={{ background: th.fgA(0.2) }}>
        <div style={{ position: "absolute", inset: 0, borderRadius: "inherit", background: th.green, opacity: clamp(on) }} />
        <div style={{ position: "absolute", top: 12, left: 12 + (w - h) * on, width: h - 24, height: h - 24, borderRadius: "50%", background: "#fff", boxShadow: "0 8px 24px rgba(0,0,0,0.35)" }} />
      </Box>
    </>
  );
};

// 26 ----------------------------------------------------------------- Segmented
export const Segmented = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const p = A(lt, 0.1, SN);
  const sw = A(lt, S_(S, 1, 7) - 0.1, SN);
  const segW = 380, y0 = 190;
  const tm = tw(W, "minor", 0, 2.4);
  const trust1 = A(lt, tm + 0.3, SM) * (1 - sw);
  const trust2 = A(lt, S_(S, 1, 7) + 1.0, SM) * sw;
  const trust = 0.18 + 0.66 * (trust1 + trust2);
  const notch = A(lt, tm - 0.1, BN) * (1 - sw);
  const b1 = A(lt, S_(S, 1, 7) + 0.3, SN), b2 = A(lt, S_(S, 1, 7) + 0.9, SN);
  return (
    <>
      <Box x={CX} y={y0} w={segW * 2 + 16} h={84} r={42} style={{ background: th.fgA(0.16), opacity: p }}>
        <div style={{ position: "absolute", left: 8 + segW * sw, top: 8, width: segW, height: 68, borderRadius: 34, background: th.surface, boxShadow: "0 4px 16px rgba(0,0,0,0.12)" }} />
        <div style={{ position: "absolute", left: 8, top: 0, width: segW, height: 84, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 32, fontWeight: 600, color: th.fg }}>Negotiation</div>
        <div style={{ position: "absolute", left: 8 + segW, top: 0, width: segW, height: 84, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 32, fontWeight: 600, color: th.fg }}>First meeting</div>
      </Box>
      <Box x={CX} y={CY + 80} w={1100} h={380} r={60} style={{ background: th.surface, boxShadow: th.shadow, opacity: p }}>
        {sw < 0.5 ? (
          <>
            <Circ x={260} y={130} d={120} style={{ background: th.blue }} />
            <Circ x={840} y={130} d={120} style={{ background: th.fg }} />
            <div style={{ position: "absolute", left: 340, top: 128, width: 420, borderTop: `5px dotted ${th.fgA(0.35)}` }} />
            <Circ x={310} y={86} d={34 * notch} style={{ background: th.warm }} />
          </>
        ) : (
          <>
            <Box x={330} y={110 + (1 - b1) * 20} w={380} h={86} r={43} style={{ background: th.fgA(0.12), opacity: clamp(b1 * 1.6), transform: `scale(${0.9 + 0.1 * b1})` }}>
              <div style={{ display: "flex", gap: 12, height: "100%", alignItems: "center", justifyContent: "center" }}>
                {[0, 1, 2].map((i) => <div key={i} style={{ width: 16, height: 16, borderRadius: 8, background: th.fgA(0.45), transform: `translateY(${-8 * Math.max(0, Math.sin(lt * 6 - i * 0.7))}px)` }} />)}
              </div>
            </Box>
            <Box x={770} y={200 + (1 - b2) * 20} w={380} h={86} r={43} style={{ background: th.blue, opacity: clamp(b2 * 1.6), transform: `scale(${0.9 + 0.1 * b2})` }}>
              <div style={{ display: "flex", gap: 12, height: "100%", alignItems: "center", justifyContent: "center" }}>
                {[0, 1, 2].map((i) => <div key={i} style={{ width: 16, height: 16, borderRadius: 8, background: "#fff", transform: `translateY(${-8 * Math.max(0, Math.sin(lt * 6 - i * 0.7 + 1))}px)` }} />)}
              </div>
            </Box>
          </>
        )}
        <Label x={160} y={310} size={28} weight={600} color={th.fgA(0.5)} w={200} style={{ letterSpacing: "0.15em" }}>TRUST</Label>
        <Box x={620} y={310} w={760} h={26} r={13} style={{ background: th.fgA(0.16) }} />
        <div style={{ position: "absolute", left: 240, top: 297, width: 760 * trust, height: 26, borderRadius: 13, background: th.green, boxShadow: `0 0 26px ${th.green}` }} />
      </Box>
    </>
  );
};

// 27 --------------------------------------------------------------- Calibration
export const Calibration = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const x0 = 360, x1 = 1560, y = CY + 10;
  const p = A(lt, 0.1, SN);
  const tc = tw(W, "coffee", 0, S_(S, 2, 7) + 3.0);
  const tu = tw(W, "unprepared", 0, tc + 2);
  const sweep = 0.5 + 0.28 * Math.sin(lt * 3.2) * (1 - rp(lt, S_(S, 1, 1.4) - 0.1, S_(S, 1, 1.4) + 0.3));
  const small = A(lt, S_(S, 1, 1.4) + 0.1, SN);
  const bad = A(lt, tu - 0.15, SN);
  const pos = lt < S_(S, 1, 1.4) ? sweep : lerp(lerp(0.5, 0.14, small), 0.9, bad);
  return (
    <>
      <Label x={CX} y={y - 175} size={28} color={th.fgA(0.5)} style={{ letterSpacing: "0.22em", opacity: p }}>SIZE OF THE MISTAKE</Label>
      <Box x={CX} y={y} w={(x1 - x0) * p} h={26} r={13} style={{ background: `linear-gradient(90deg, ${th.green} 0%, ${th.warm} 50%, ${th.red} 100%)`, opacity: 0.95 }} />
      <Circ x={x0 + (x1 - x0) * pos} y={y} d={84} style={{ background: "#fff", boxShadow: "0 8px 28px rgba(0,0,0,0.4)" }} />
      <Chip x={x0 + (x1 - x0) * 0.16} y={y - 100} w={320} h={60} p={A(lt, tc - 0.1, SN)} color={th.green} icon={<Check s={26} />} text="Spilling coffee" />
      <Chip x={x0 + (x1 - x0) * 0.86} y={y - 100} w={410} h={60} p={A(lt, tu - 0.1, SN)} color={th.red} icon={<Cross s={26} />} text="Showing up unprepared" />
    </>
  );
};

// 28 ------------------------------------------------------------------- Delivery
export const Delivery = ({ lt, S, W }: VP) => {
  const th = useTheme();
  const tA = tw(W, "owns", 0, S_(S, 1, 2) + 1.2);
  const tB = tw(W, "collapses", 0, S_(S, 2, 7) + 2);
  const fall = 0.45;
  const xs = [620, 1300];
  const cy = CY - 10;
  const tt = [tA, tB];
  const p = A(lt, 0.1, SN);
  return (
    <>
      {xs.map((x, i) => {
        const t = tt[i];
        const u = clamp((lt - t) / fall);
        const land = lt - (t + fall);
        const hit = land > 0 ? A(lt, t + fall, i === 0 ? SN : SOFT) : 0;
        const sq = i === 1 ? hit : 0;
        const ok = i === 0 ? hit : 0;
        const meter = i === 0 ? 0.45 + 0.4 * A(lt, t + fall + 0.15, SM) : 0.45 - 0.33 * A(lt, t + fall + 0.15, SM);
        return (
          <React.Fragment key={i}>
            <Circ x={x} y={cy + 90 * sq * 0.5} d={190 * p} style={{ background: i === 0 ? th.blue : th.fg, transform: `scale(${1 + 0.18 * sq}, ${1 - 0.42 * sq})`, boxShadow: i === 0 && ok > 0.05 ? `0 0 ${50 * ok}px ${th.blue}` : "none" }} />
            {u > 0 && land < 0 && <Circ x={x} y={-50 + (cy - 20 + 50) * u * u} d={40} style={{ background: th.warm }} />}
            {land > 0 && <Circ x={x} y={cy - 12} d={40 + 280 * rp(land, 0, 0.8)} style={{ border: `3px solid ${th.warm}`, opacity: 1 - rp(land, 0, 0.8) }} />}
            <Label x={x} y={cy + 190} size={40} weight={700} color={th.fg} w={500} style={{ opacity: p }}>{i === 0 ? "Owns it" : "Collapses"}</Label>
            <Box x={x} y={cy + 260} w={360} h={20} r={10} style={{ background: th.fgA(0.16), opacity: p }} />
            <div style={{ position: "absolute", left: x - 180, top: cy + 250, width: 360 * meter, height: 20, borderRadius: 10, background: i === 0 ? th.green : th.red, opacity: p }} />
          </React.Fragment>
        );
      })}
    </>
  );
};

// 29 -------------------------------------------------------------------- Patches
export const Patches = ({ lt, dur, S }: VP) => {
  const th = useTheme();
  const cols = 10, rows = 4, step = 104;
  const r = rnd(7);
  const order = Array.from({ length: cols * rows }, (_, i) => ({ i, k: r() })).sort((a, b) => a.k - b.k).map((o) => o.i);
  const rank: number[] = [];
  order.forEach((cell, ri) => (rank[cell] = ri));
  return (
    <>
      {Array.from({ length: cols * rows }).map((_, n) => {
        const c = n % cols, rr = Math.floor(n / cols);
        const x = CX + (c - (cols - 1) / 2) * step, y = CY + (rr - (rows - 1) / 2) * step;
        const wave = Math.floor(rank[n] / 10);
        const t = S_(S, wave, (dur / 4) * wave) + 0.25 + (rank[n] % 10) * 0.085;
        const dp = A(lt, 0.05 + (c + rr) * 0.03, SN);
        const pp = A(lt, t, SN);
        return (
          <React.Fragment key={n}>
            <Circ x={x} y={y} d={28 * dp} style={{ background: th.warm, boxShadow: `0 0 18px ${th.warm}` }} />
            <Box x={x} y={y} w={88 * pp} h={88 * pp} r={26} style={{ background: th.fg, opacity: clamp(pp * 1.6) }} />
          </React.Fragment>
        );
      })}
    </>
  );
};

// 30 ------------------------------------------------------------------- Scribble
export const Scribble = ({ lt, dur }: VP) => {
  const th = useTheme();
  const pts: string[] = [];
  const N = 360;
  for (let i = 0; i <= N; i++) {
    const u = i / N;
    const x = 330 + 1260 * u + 130 * Math.sin(14 * u + 0.4);
    const y = CY + 120 * Math.sin(9 * u + 0.4) + 70 * Math.sin(23 * u);
    pts.push(`${i === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`);
  }
  const prog = rp(lt, 0.2, dur - 0.5, eIO);
  return (
    <svg style={{ position: "absolute", left: 0, top: 0, filter: "drop-shadow(0 0 22px rgba(255,149,0,0.35))" }} width={1920} height={1080}>
      <defs>
        <linearGradient id="sg1" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor={th.warm} />
          <stop offset="100%" stopColor={th.blue} />
        </linearGradient>
      </defs>
      <path d={pts.join(" ")} fill="none" stroke="url(#sg1)" strokeWidth={16} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - prog} />
    </svg>
  );
};

// 31 -------------------------------------------------------------------- Stumble
export const Stumble = ({ lt, dur, S, W }: VP) => {
  const th = useTheme();
  const ground = 640, r = 60;
  const stepX = 1100, stepW = 420, stepH = 84; // wall face at stepX
  const yG = ground - r;                // ball center on the ground
  const yT = ground - stepH - r;        // ball center on top of the step
  const xc = stepX - r;                 // ball center when touching the wall
  const x0 = 220, t0 = 0.4;
  const ts = tw(W, "stumble", 1, S_(S, 1, 7) + 1.2);       // hits the wall
  const bounceEnd = ts + 0.6;
  const tr = Math.max(bounceEnd + 0.15, tw(W, "recover", 0, ts + 1.4) - 0.1); // starts the hop
  const hopT = 0.85;
  const xb = xc - 62;                    // resting spot after bouncing back
  const xTop = stepX + 95;               // landing spot on the step
  const tRoll = tr + hopT;
  const t1 = dur - 0.9;
  const xEnd = 1740;
  const vx = (xEnd - xTop) / Math.max(1, t1 - tRoll);
  let x = x0, y = yG, sx = 1, sy = 1;
  if (lt < ts) {
    const u = clamp((lt - t0) / (ts - t0));
    x = lerp(x0, xc, Math.pow(u, 1.25));
  } else if (lt < bounceEnd) {
    const u = clamp((lt - ts) / (bounceEnd - ts));
    x = lerp(xc, xb, eOut(u));
    y = yG - 14 * Math.sin(Math.PI * u) * 1.0;
    const k = Math.exp(-(lt - ts) * 16);
    sx = 1 - 0.2 * k; sy = 1 + 0.12 * k;
  } else if (lt < tr) {
    x = xb;
  } else if (lt < tRoll) {
    const u = clamp((lt - tr) / hopT);
    x = lerp(xb, xTop, u);
    y = lerp(yG, yT, eOut(u)) - 175 * Math.sin(Math.PI * u);
    const k = Math.exp(-(lt - tRoll + hopT) * 0);
    sx = 1; sy = 1; void k;
  } else {
    const tt = lt - tRoll;
    x = xTop + vx * tt;
    const xe = stepX + stepW;
    if (x <= xe) y = yT;
    else {
      const f = (x - xe) / vx;
      y = Math.min(yG, yT + 0.5 * 2600 * f * f);
      if (y >= yG) { x = Math.max(x, xe + 0); }
    }
    const land = lt - tRoll;
    if (land < 0.25) { const q = Math.exp(-land * 18); sx = 1 + 0.14 * q; sy = 1 - 0.14 * q; }
  }
  const p = A(lt, 0.1, SN);
  const ang = (x / r) * (180 / Math.PI);
  return (
    <>
      <Box x={CX} y={ground + 3} w={1700 * p} h={8} r={4} style={{ background: th.fgA(0.3) }} />
      <Box x={stepX + stepW / 2} y={ground - stepH / 2} w={stepW * p} h={stepH} r={26} style={{ background: th.fgA(0.28), boxShadow: `inset 0 0 0 3px ${th.fgA(0.35)}` }} />
      {Array.from({ length: 8 }).map((_, i) => (
        <Box key={i} x={260 + i * 200} y={230} w={100 * A(lt, S_(S, 0, 0) + i * 0.08, SN)} h={100 * A(lt, S_(S, 0, 0) + i * 0.08, SN)} r={30} style={{ background: th.fgA(0.2) }} />
      ))}
      <Label x={CX} y={340} size={28} weight={600} color={th.fgA(0.45)} w={900} style={{ letterSpacing: "0.2em", opacity: A(lt, 0.8) }}>EVERYONE ELSE</Label>
      <Circ x={x} y={y + (r - r * sy)} d={r * 2 * p} style={{ background: th.blue, transform: `rotate(${ang}deg) scale(${sx}, ${sy})`, boxShadow: `0 0 50px ${th.blue}` }}>
        <div style={{ position: "absolute", left: "50%", top: 14, width: 16, height: 16, marginLeft: -8, borderRadius: 8, background: "#fff" }} />
      </Circ>
    </>
  );
};

// 32 -------------------------------------------------------------------- RingGap
export const RingGap = ({ lt, S }: VP) => {
  const th = useTheme();
  const draw = A(lt, 0.15, SOFT);
  const open = A(lt, S_(S, 1, 2) + 0.1, SN);
  const R = 190, C = 2 * Math.PI * R;
  const gapFrac = 0.09 * open;
  const dash = C * (1 - gapFrac);
  const rot = -90 + 360 * gapFrac * 0.5 + lt * 6 * open;
  const dotA = (-90 + lt * 6 * open) * (Math.PI / 180);
  return (
    <>
      <Circ x={CX} y={CY} d={560} style={{ background: `radial-gradient(circle, ${th.warm} 0%, transparent 62%)`, opacity: 0.35 * open * (0.8 + 0.2 * Math.sin(lt * 2.4)) }} />
      <svg style={{ position: "absolute", left: CX - 240, top: CY - 240 }} width={480} height={480}>
        <circle cx={240} cy={240} r={R} fill="none" stroke={th.fg} strokeWidth={18} strokeLinecap="round" strokeDasharray={`${dash * draw} ${C}`} transform={`rotate(${rot} 240 240)`} />
      </svg>
      <Circ x={CX + Math.cos(dotA) * R} y={CY + Math.sin(dotA) * R} d={46 * open} style={{ background: th.warm, boxShadow: `0 0 36px ${th.warm}` }} />
    </>
  );
};

// 33 -------------------------------------------------------------------- Question
export const Question = ({ lt, S }: VP) => {
  const th = useTheme();
  const p = A(lt, 0.1, SN);
  const q = A(lt, 0.7, BN);
  const breathe = 1 + 0.04 * Math.sin(lt * 2.2);
  return (
    <>
      <Circ x={CX} y={CY - 20} d={460 * breathe} style={{ background: `radial-gradient(circle, ${th.fgA(0.18)} 0%, transparent 68%)`, opacity: p }} />
      <div style={{ opacity: clamp(p * 1.6), transform: `scale(${0.9 + 0.1 * p})`, transformOrigin: `${CX}px ${CY}px` }}>
        <Person x={CX} y={CY - 10} s={270} color={th.fg} />
      </div>
      <Label x={CX + 210} y={CY - 140} size={100} weight={700} color={th.blue} w={200} style={{ transform: `scale(${q}) rotate(${12 * Math.sin(lt * 2)}deg)`, opacity: clamp(q * 1.6) }}>?</Label>
      <Chip x={600} y={CY + 250} w={500} h={100} size={38} p={A(lt, S_(S, 1, 3) - 0.05, SN)} color={th.surface} tc={th.fg} text="Shows small flaws" />
      <Chip x={1320} y={CY + 250} w={500} h={100} size={38} p={A(lt, S_(S, 2, 5) - 0.05, SN)} color={th.surface} tc={th.fg} text="Completely flawless" />
    </>
  );
};

// 34 ------------------------------------------------------------------ Comments
export const Comments = ({ lt, S }: VP) => {
  const th = useTheme();
  const p = A(lt, 0.1, BN);
  const bye = A(lt, S_(S, 1, 2.5), SOFT);
  return (
    <div style={{ opacity: 1 - 0.0 * bye, transform: `scale(${1 - 0.06 * bye})`, transformOrigin: `${CX}px ${CY}px` }}>
      <Box x={CX} y={CY - 10} w={600} h={250} r={90} style={{ background: th.surface, boxShadow: th.shadow, transform: `scale(${p})`, opacity: clamp(p * 1.6) }}>
        <div style={{ display: "flex", gap: 22, height: "100%", alignItems: "center", justifyContent: "center" }}>
          {[0, 1, 2].map((i) => <div key={i} style={{ width: 40, height: 40, borderRadius: 20, background: i === 1 ? th.blue : th.fgA(0.4), transform: `translateY(${-22 * Math.max(0, Math.sin(lt * 5 - i * 0.7))}px)` }} />)}
        </div>
      </Box>
      <Circ x={CX - 220} y={CY + 140} d={46 * p} style={{ background: th.surface, boxShadow: th.shadow }} />
      <Circ x={CX - 262} y={CY + 186} d={24 * p} style={{ background: th.surface, boxShadow: th.shadow }} />
      <Label x={CX} y={CY + 250} size={36} weight={600} color={th.fgA(0.5)} style={{ letterSpacing: "0.2em", opacity: A(lt, 0.5) }}>COMMENTS</Label>
    </div>
  );
};
