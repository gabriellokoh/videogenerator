import React from "react";
import { Composition, registerRoot } from "remotion";
import { MyVideo } from "./Video";
import { TOTAL } from "./timeline";
import { FPS } from "./lib";

export const RemotionRoot: React.FC = () => (
  <Composition
    id="MyVideo"
    component={MyVideo}
    durationInFrames={Math.ceil(TOTAL * FPS)}
    fps={FPS}
    width={2560}
    height={1440}
  />
);

registerRoot(RemotionRoot);
