import React from "react";
import * as A from "./visualsA";
import * as B from "./visualsB";

const Hero: React.FC<any> = () => null;
export const VIS: Record<string, React.FC<any>> = { Hero, ...A, ...B } as any;
